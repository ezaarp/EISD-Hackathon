(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/supabase.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "deleteFile",
    ()=>deleteFile,
    "getFileUrl",
    ()=>getFileUrl,
    "supabase",
    ()=>supabase,
    "supabaseAdmin",
    ()=>supabaseAdmin,
    "uploadFile",
    ()=>uploadFile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-client] (ecmascript) <locals>");
;
const supabaseUrl = ("TURBOPACK compile-time value", "https://oyfigjfooeoabvkavubu.supabase.co");
const supabaseAnonKey = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im95ZmlnamZvb2VvYWJ2a2F2dWJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQzMjU0MDMsImV4cCI6MjA3OTkwMTQwM30.VO4fK5BbLQh0BqhN8K4GW4Cg-wWLhsvlwWpVQpSjBvU");
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseAnonKey);
// Server-side Supabase client with service role (for admin operations)
const supabaseServiceKey = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.SUPABASE_SERVICE_ROLE_KEY;
const supabaseAdmin = supabaseServiceKey ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseServiceKey) : null;
async function uploadFile(bucket, path, file, options) {
    const client = supabaseAdmin || supabase;
    const { data, error } = await client.storage.from(bucket).upload(path, file, {
        contentType: options?.contentType,
        cacheControl: options?.cacheControl || '3600',
        upsert: options?.upsert || false
    });
    if (error) {
        throw error;
    }
    // Get public URL
    const { data: urlData } = client.storage.from(bucket).getPublicUrl(path);
    return {
        path: data.path,
        publicUrl: urlData.publicUrl
    };
}
async function deleteFile(bucket, path) {
    const client = supabaseAdmin || supabase;
    const { error } = await client.storage.from(bucket).remove([
        path
    ]);
    if (error) {
        throw error;
    }
    return true;
}
function getFileUrl(bucket, path) {
    // Private buckets (evidence, violations, permissions) need signed URLs
    const privateBuckets = [
        'evidence',
        'violations',
        'permissions'
    ];
    if (privateBuckets.includes(bucket)) {
        // For private buckets, we need to generate signed URLs on the server
        // This function will return a path that will be handled by an API route
        return `/api/files/${bucket}/${encodeURIComponent(path)}`;
    }
    // For public buckets, use public URL
    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    return data.publicUrl;
}
const __TURBOPACK__default__export__ = supabase;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/PixelButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
;
const PixelButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = ({ variant = 'primary', className = '', disabled = false, children, href, ...props }, ref)=>{
    const variants = {
        primary: 'bg-indigo-500 hover:bg-indigo-400 text-white border-b-4 border-indigo-700 active:border-b-0 active:mt-1',
        success: 'bg-emerald-500 hover:bg-emerald-400 text-black border-b-4 border-emerald-700 active:border-b-0 active:mt-1',
        danger: 'bg-rose-500 hover:bg-rose-400 text-white border-b-4 border-rose-700 active:border-b-0 active:mt-1',
        warning: 'bg-amber-400 hover:bg-amber-300 text-black border-b-4 border-amber-600 active:border-b-0 active:mt-1',
        neutral: 'bg-slate-300 hover:bg-slate-200 text-black border-b-4 border-slate-500 active:border-b-0 active:mt-1',
        secondary: 'bg-slate-700 hover:bg-slate-600 text-white border-b-4 border-slate-900 active:border-b-0 active:mt-1',
        outline: 'bg-transparent border-2 border-slate-500 hover:bg-slate-800 text-slate-300 active:translate-y-1'
    };
    const baseStyles = `
      font-pixel text-xs px-4 py-3 transition-all duration-75 uppercase tracking-wider flex items-center justify-center
      ${variants[variant]}
      ${disabled ? 'opacity-50 cursor-not-allowed active:border-b-4 active:mt-0' : ''}
      ${className}
    `;
    if (href && !disabled) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: href,
            className: baseStyles,
            children: children
        }, void 0, false, {
            fileName: "[project]/components/ui/PixelButton.tsx",
            lineNumber: 33,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        ref: ref,
        disabled: disabled,
        className: baseStyles,
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/PixelButton.tsx",
        lineNumber: 40,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = PixelButton;
PixelButton.displayName = 'PixelButton';
const __TURBOPACK__default__export__ = PixelButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "PixelButton$React.forwardRef");
__turbopack_context__.k.register(_c1, "PixelButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/PixelCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const PixelCard = ({ title, children, className = '', color = 'bg-slate-800' })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `pixel-card ${color} ${className}`,
        children: [
            title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute -top-5 left-2 bg-black text-white px-2 py-1 text-xs font-bold border-2 border-white",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/ui/PixelCard.tsx",
                lineNumber: 19,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/PixelCard.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = PixelCard;
const __TURBOPACK__default__export__ = PixelCard;
var _c;
__turbopack_context__.k.register(_c, "PixelCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/StatusBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const StatusBar = ({ label, current, max, color, icon: Icon, showValues = true })=>{
    const percent = Math.min(current / max * 100, 100);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-2 w-full mb-2",
        children: [
            Icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-8 flex justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                    size: 16,
                    className: color.replace('bg-', 'text-')
                }, void 0, false, {
                    fileName: "[project]/components/ui/StatusBar.tsx",
                    lineNumber: 27,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/components/ui/StatusBar.tsx",
                lineNumber: 26,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1",
                children: [
                    showValues && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between text-[10px] mb-1 uppercase font-bold text-slate-400",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: label
                            }, void 0, false, {
                                fileName: "[project]/components/ui/StatusBar.tsx",
                                lineNumber: 33,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    current,
                                    "/",
                                    max
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ui/StatusBar.tsx",
                                lineNumber: 34,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ui/StatusBar.tsx",
                        lineNumber: 32,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "pixel-progress",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `pixel-progress-bar ${color}`,
                            style: {
                                width: `${percent}%`
                            }
                        }, void 0, false, {
                            fileName: "[project]/components/ui/StatusBar.tsx",
                            lineNumber: 40,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/components/ui/StatusBar.tsx",
                        lineNumber: 39,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/StatusBar.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/StatusBar.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = StatusBar;
const __TURBOPACK__default__export__ = StatusBar;
var _c;
__turbopack_context__.k.register(_c, "StatusBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/Timer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const Timer = ({ endTime, onComplete, className = '' })=>{
    _s();
    const [timeLeft, setTimeLeft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Timer.useEffect": ()=>{
            if (!endTime) {
                setTimeLeft(0);
                return;
            }
            const calculateTimeLeft = {
                "Timer.useEffect.calculateTimeLeft": ()=>{
                    const now = new Date().getTime();
                    const end = new Date(endTime).getTime();
                    const diff = Math.max(0, Math.floor((end - now) / 1000));
                    return diff;
                }
            }["Timer.useEffect.calculateTimeLeft"];
            setTimeLeft(calculateTimeLeft());
            const interval = setInterval({
                "Timer.useEffect.interval": ()=>{
                    const left = calculateTimeLeft();
                    setTimeLeft(left);
                    if (left === 0 && onComplete) {
                        onComplete();
                    }
                }
            }["Timer.useEffect.interval"], 1000);
            return ({
                "Timer.useEffect": ()=>clearInterval(interval)
            })["Timer.useEffect"];
        }
    }["Timer.useEffect"], [
        endTime,
        onComplete
    ]);
    const formatTime = (seconds)=>{
        const h = Math.floor(seconds / 3600);
        const m = Math.floor(seconds % 3600 / 60);
        const s = seconds % 60;
        if (h > 0) {
            return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
        }
        return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    };
    const isWarning = timeLeft > 0 && timeLeft <= 60;
    const isDanger = timeLeft > 0 && timeLeft <= 30;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex items-center gap-2 ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                size: 20,
                className: `${isDanger ? 'text-rose-500' : isWarning ? 'text-amber-400' : 'text-slate-400'}`
            }, void 0, false, {
                fileName: "[project]/components/ui/Timer.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `text-2xl font-bold font-mono ${isDanger ? 'text-rose-500 blink' : isWarning ? 'text-amber-400' : 'text-white'}`,
                children: formatTime(timeLeft)
            }, void 0, false, {
                fileName: "[project]/components/ui/Timer.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/Timer.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Timer, "+8R8qG0ytIJ3hDO9yvGoGENFV+4=");
_c = Timer;
const __TURBOPACK__default__export__ = Timer;
var _c;
__turbopack_context__.k.register(_c, "Timer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/Loading.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const Loading = ({ text = 'Loading...', fullscreen = false })=>{
    const content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-center justify-center gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-12 h-12 border-4 border-slate-700 border-t-emerald-400 animate-spin"
                }, void 0, false, {
                    fileName: "[project]/components/ui/Loading.tsx",
                    lineNumber: 12,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/components/ui/Loading.tsx",
                lineNumber: 11,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-slate-400 uppercase font-bold animate-pulse",
                children: text
            }, void 0, false, {
                fileName: "[project]/components/ui/Loading.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/Loading.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
    if (fullscreen) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-slate-900 flex items-center justify-center",
            children: content
        }, void 0, false, {
            fileName: "[project]/components/ui/Loading.tsx",
            lineNumber: 20,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "py-12",
        children: content
    }, void 0, false, {
        fileName: "[project]/components/ui/Loading.tsx",
        lineNumber: 26,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Loading;
const __TURBOPACK__default__export__ = Loading;
var _c;
__turbopack_context__.k.register(_c, "Loading");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/PresentationViewer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PresentationViewer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/PixelButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function PresentationViewer({ liveSessionId, presentationUrl, isController = false, initialSlide = 1, presentationType = 'TP' }) {
    _s();
    const [currentSlide, setCurrentSlide] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialSlide);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PresentationViewer.useEffect": ()=>{
            if (isController) return; // Controller doesn't listen, it broadcasts
            // Use a dedicated channel for presentation to avoid conflicts with main live channel
            const channel = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].channel(`live-presentation-${liveSessionId}`).on('broadcast', {
                event: 'slide_change'
            }, {
                "PresentationViewer.useEffect.channel": (payload)=>{
                    console.log('[PresentationViewer] Slide change:', payload);
                    if (payload.payload.presentationType === presentationType) {
                        setCurrentSlide(payload.payload.slide);
                    }
                }
            }["PresentationViewer.useEffect.channel"]).subscribe();
            return ({
                "PresentationViewer.useEffect": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].removeChannel(channel);
                }
            })["PresentationViewer.useEffect"];
        }
    }["PresentationViewer.useEffect"], [
        liveSessionId,
        isController,
        presentationType
    ]);
    const handleSlideChange = async (newSlide)=>{
        if (!isController) return;
        setCurrentSlide(newSlide);
        // Update database and broadcast
        await fetch('/api/change-slide', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                liveSessionId,
                slideNumber: newSlide,
                presentationType
            })
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full aspect-[16/9] bg-slate-950 border-2 border-slate-700 overflow-hidden relative",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
                    src: `${presentationUrl}#page=${currentSlide}`,
                    className: "w-full h-full",
                    title: "Presentation Viewer"
                }, void 0, false, {
                    fileName: "[project]/components/ui/PresentationViewer.tsx",
                    lineNumber: 64,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ui/PresentationViewer.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            isController && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between bg-slate-800 border-2 border-slate-700 p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "outline",
                        onClick: ()=>handleSlideChange(Math.max(1, currentSlide - 1)),
                        disabled: currentSlide <= 1,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                size: 20,
                                className: "mr-2"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/PresentationViewer.tsx",
                                lineNumber: 79,
                                columnNumber: 13
                            }, this),
                            "PREV"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ui/PresentationViewer.tsx",
                        lineNumber: 74,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "font-pixel text-2xl text-white",
                                children: currentSlide
                            }, void 0, false, {
                                fileName: "[project]/components/ui/PresentationViewer.tsx",
                                lineNumber: 84,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-slate-400",
                                children: "Slide Number"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/PresentationViewer.tsx",
                                lineNumber: 85,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ui/PresentationViewer.tsx",
                        lineNumber: 83,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "outline",
                        onClick: ()=>handleSlideChange(currentSlide + 1),
                        children: [
                            "NEXT",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                size: 20,
                                className: "ml-2"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/PresentationViewer.tsx",
                                lineNumber: 93,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ui/PresentationViewer.tsx",
                        lineNumber: 88,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/PresentationViewer.tsx",
                lineNumber: 73,
                columnNumber: 9
            }, this),
            !isController && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center bg-slate-800 border border-slate-700 p-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-slate-400",
                    children: [
                        "Slide ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-bold text-white",
                            children: currentSlide
                        }, void 0, false, {
                            fileName: "[project]/components/ui/PresentationViewer.tsx",
                            lineNumber: 101,
                            columnNumber: 55
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ui/PresentationViewer.tsx",
                    lineNumber: 101,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ui/PresentationViewer.tsx",
                lineNumber: 100,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/PresentationViewer.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
}
_s(PresentationViewer, "cK4re7bxavZclP8Kf8F1wIdjSqo=");
_c = PresentationViewer;
var _c;
__turbopack_context__.k.register(_c, "PresentationViewer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/PixelButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/PixelCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$StatusBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/StatusBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Timer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Timer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Loading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Loading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PresentationViewer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/PresentationViewer.tsx [app-client] (ecmascript)");
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/PixelCard.tsx [app-client] (ecmascript) <export default as PixelCard>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PixelCard",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/PixelCard.tsx [app-client] (ecmascript)");
}),
"[project]/components/ui/PixelButton.tsx [app-client] (ecmascript) <export default as PixelButton>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PixelButton",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/PixelButton.tsx [app-client] (ecmascript)");
}),
"[project]/app/actions/data:3fa5ef [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"7008072e7a5434a3cfec3f68454d1ff8017df8eba4":"submitMCQ"},"app/actions/submission.ts",""] */ __turbopack_context__.s([
    "submitMCQ",
    ()=>submitMCQ
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var submitMCQ = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("7008072e7a5434a3cfec3f68454d1ff8017df8eba4", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "submitMCQ"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vc3VibWlzc2lvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcic7XHJcblxyXG5pbXBvcnQgeyBwcmlzbWEgfSBmcm9tICdAL2xpYi9wcmlzbWEnO1xyXG5pbXBvcnQgeyBnZXRTZXJ2ZXJTZXNzaW9uIH0gZnJvbSAnbmV4dC1hdXRoJztcclxuaW1wb3J0IHsgYXV0aE9wdGlvbnMgfSBmcm9tICdAL2xpYi9hdXRoJztcclxuaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tICduZXh0L2NhY2hlJztcclxuaW1wb3J0IHsgdXBsb2FkRmlsZSB9IGZyb20gJ0AvbGliL3N1cGFiYXNlJztcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzdWJtaXRNQ1EodGFza0lkOiBzdHJpbmcsIGFuc3dlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4sIGxpdmVTZXNzaW9uSWQ/OiBzdHJpbmcpIHtcclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2VydmVyU2Vzc2lvbihhdXRoT3B0aW9ucyk7XHJcbiAgaWYgKCFzZXNzaW9uKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xyXG5cclxuICBjb25zdCB0YXNrID0gYXdhaXQgcHJpc21hLnRhc2suZmluZFVuaXF1ZSh7XHJcbiAgICB3aGVyZTogeyBpZDogdGFza0lkIH0sXHJcbiAgICBpbmNsdWRlOiB7IHF1ZXN0aW9uczogeyBpbmNsdWRlOiB7IGFuc3dlcktleTogdHJ1ZSB9IH0gfVxyXG4gIH0pO1xyXG5cclxuICBpZiAoIXRhc2spIHRocm93IG5ldyBFcnJvcignVGFzayBub3QgZm91bmQnKTtcclxuXHJcbiAgLy8gQ2FsY3VsYXRlIHNjb3JlXHJcbiAgbGV0IHRvdGFsUG9pbnRzID0gMDtcclxuICBsZXQgZWFybmVkUG9pbnRzID0gMDtcclxuICBjb25zdCBwcm9jZXNzZWRBbnN3ZXJzOiBhbnlbXSA9IFtdO1xyXG5cclxuICBjb25zdCBub3JtYWxpemUgPSAodmFsdWU/OiBzdHJpbmcgfCBudWxsKSA9PiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IHZhbHVlLnRyaW0oKSA6ICcnKTtcclxuICBjb25zdCBwYXJzZU9wdGlvbnMgPSAob3B0aW9uc0pzb24/OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nW10gPT4ge1xyXG4gICAgICBpZiAoIW9wdGlvbnNKc29uKSByZXR1cm4gW107XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKG9wdGlvbnNKc29uKTtcclxuICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHBhcnNlZCkpIHtcclxuICAgICAgICAgICAgICByZXR1cm4gcGFyc2VkLm1hcCgob3B0KSA9PiAodHlwZW9mIG9wdCA9PT0gJ3N0cmluZycgPyBvcHQgOiBTdHJpbmcob3B0KSkpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgY29uc29sZS53YXJuKCdGYWlsZWQgdG8gcGFyc2Ugb3B0aW9ucyBKU09OJywgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBbXTtcclxuICB9O1xyXG5cclxuICBmb3IgKGNvbnN0IHF1ZXN0aW9uIG9mIHRhc2sucXVlc3Rpb25zKSB7XHJcbiAgICAgIGNvbnN0IHN0dWRlbnRBbnN3ZXIgPSBub3JtYWxpemUoYW5zd2Vyc1txdWVzdGlvbi5pZF0pO1xyXG4gICAgICBjb25zdCBwb2ludHMgPSBxdWVzdGlvbi5wb2ludHMgfHwgMTA7IC8vIERlZmF1bHQgcG9pbnRzIGlmIG5vdCBzZXRcclxuICAgICAgdG90YWxQb2ludHMgKz0gcG9pbnRzO1xyXG5cclxuICAgICAgaWYgKHN0dWRlbnRBbnN3ZXIpIHtcclxuICAgICAgICAgIGNvbnN0IHJhd0Fuc3dlcktleSA9IG5vcm1hbGl6ZShxdWVzdGlvbi5hbnN3ZXJLZXk/LmNvcnJlY3RBbnN3ZXIpO1xyXG4gICAgICAgICAgbGV0IGlzQ29ycmVjdCA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgIGlmIChyYXdBbnN3ZXJLZXkpIHtcclxuICAgICAgICAgICAgICAvLyBQcmltYXJ5OiBjb21wYXJlIHJhdyBzdHJpbmdzIChjb3ZlcnMgbnVtZXJpYyBpbmRleGVzIHN0b3JlZCBhcyBzdHJpbmdzKVxyXG4gICAgICAgICAgICAgIGlmIChyYXdBbnN3ZXJLZXkgPT09IHN0dWRlbnRBbnN3ZXIpIHtcclxuICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBvcHRpb25zID0gcGFyc2VPcHRpb25zKHF1ZXN0aW9uLm9wdGlvbnNKc29uKTtcclxuICAgICAgICAgICAgICAgICAgY29uc3Qgc3R1ZGVudEluZGV4ID0gTnVtYmVyKHN0dWRlbnRBbnN3ZXIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgLy8gSWYgYW5zd2VyIGtleSBzdG9yZWQgYXMgb3B0aW9uIHRleHQsIGNvbXBhcmUgc2VsZWN0ZWQgb3B0aW9uIHRleHRcclxuICAgICAgICAgICAgICAgICAgaWYgKCFOdW1iZXIuaXNOYU4oc3R1ZGVudEluZGV4KSAmJiBvcHRpb25zW3N0dWRlbnRJbmRleF0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkT3B0aW9uID0gbm9ybWFsaXplKG9wdGlvbnNbc3R1ZGVudEluZGV4XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZWN0ZWRPcHRpb24gJiYgc2VsZWN0ZWRPcHRpb24udG9Mb3dlckNhc2UoKSA9PT0gcmF3QW5zd2VyS2V5LnRvTG93ZXJDYXNlKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3QgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAvLyBJZiBhbnN3ZXIga2V5IHN0b3JlZCBhcyBsZXR0ZXIgKEEsIEIsIEMuLi4pLCBtYXAgdG8gaW5kZXhcclxuICAgICAgICAgICAgICAgICAgaWYgKCFpc0NvcnJlY3QgJiYgL15bQS1aYS16XSQvLnRlc3QocmF3QW5zd2VyS2V5KSAmJiAhTnVtYmVyLmlzTmFOKHN0dWRlbnRJbmRleCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxldHRlckluZGV4ID0gcmF3QW5zd2VyS2V5LnRvVXBwZXJDYXNlKCkuY2hhckNvZGVBdCgwKSAtIDY1O1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGxldHRlckluZGV4ID09PSBzdHVkZW50SW5kZXgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3QgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGlmIChpc0NvcnJlY3QpIHtcclxuICAgICAgICAgICAgICBlYXJuZWRQb2ludHMgKz0gcG9pbnRzO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBwcm9jZXNzZWRBbnN3ZXJzLnB1c2goe1xyXG4gICAgICAgICAgICAgIHF1ZXN0aW9uSWQ6IHF1ZXN0aW9uLmlkLFxyXG4gICAgICAgICAgICAgIGFuc3dlcjogc3R1ZGVudEFuc3dlcixcclxuICAgICAgICAgICAgICBpc0NvcnJlY3RcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBmaW5hbFNjb3JlID0gdG90YWxQb2ludHMgPiAwID8gKGVhcm5lZFBvaW50cyAvIHRvdGFsUG9pbnRzKSAqIDEwMCA6IDA7XHJcblxyXG4gIC8vIENoZWNrIGZvciBleGlzdGluZyBzdWJtaXNzaW9uIGZvciB0aGlzIFRBU0sgKG5vdCBwZXIgcXVlc3Rpb24pXHJcbiAgY29uc3QgZXhpc3RpbmdTdWJtaXNzaW9uID0gYXdhaXQgcHJpc21hLnN1Ym1pc3Npb24uZmluZEZpcnN0KHtcclxuICAgICAgd2hlcmU6IHtcclxuICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgIHN0dWRlbnRJZDogc2Vzc2lvbi51c2VyLmlkLFxyXG4gICAgICAgICAgcXVlc3Rpb25JZDogbnVsbCAvLyBUYXNrLWxldmVsIHN1Ym1pc3Npb25cclxuICAgICAgfVxyXG4gIH0pO1xyXG5cclxuICBsZXQgc3VibWlzc2lvbklkID0gZXhpc3RpbmdTdWJtaXNzaW9uPy5pZDtcclxuXHJcbiAgaWYgKGV4aXN0aW5nU3VibWlzc2lvbikge1xyXG4gICAgICBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi51cGRhdGUoe1xyXG4gICAgICAgICAgd2hlcmU6IHsgaWQ6IGV4aXN0aW5nU3VibWlzc2lvbi5pZCB9LFxyXG4gICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgIGFuc3dlcnNKc29uOiBKU09OLnN0cmluZ2lmeShwcm9jZXNzZWRBbnN3ZXJzKSxcclxuICAgICAgICAgICAgICBzdGF0dXM6ICdHUkFERUQnLFxyXG4gICAgICAgICAgICAgIHN1Ym1pdHRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICAgICAgICAgIGxpdmVTZXNzaW9uSWRcclxuICAgICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgfSBlbHNlIHtcclxuICAgICAgY29uc3Qgc3ViID0gYXdhaXQgcHJpc21hLnN1Ym1pc3Npb24uY3JlYXRlKHtcclxuICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICB0YXNrSWQsXHJcbiAgICAgICAgICAgICAgc3R1ZGVudElkOiBzZXNzaW9uLnVzZXIuaWQsXHJcbiAgICAgICAgICAgICAgbGl2ZVNlc3Npb25JZCxcclxuICAgICAgICAgICAgICBhbnN3ZXJzSnNvbjogSlNPTi5zdHJpbmdpZnkocHJvY2Vzc2VkQW5zd2VycyksXHJcbiAgICAgICAgICAgICAgc3RhdHVzOiAnR1JBREVEJyxcclxuICAgICAgICAgICAgICBzdWJtaXR0ZWRBdDogbmV3IERhdGUoKSxcclxuICAgICAgICAgICAgICBxdWVzdGlvbklkOiBudWxsXHJcbiAgICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICBzdWJtaXNzaW9uSWQgPSBzdWIuaWQ7XHJcbiAgfVxyXG5cclxuICAvLyBDcmVhdGUgb3IgVXBkYXRlIEdyYWRlIGltbWVkaWF0ZWx5XHJcbiAgY29uc3QgZXhpc3RpbmdHcmFkZSA9IGF3YWl0IHByaXNtYS5ncmFkZS5maW5kVW5pcXVlKHtcclxuICAgICAgd2hlcmU6IHsgc3VibWlzc2lvbklkOiBzdWJtaXNzaW9uSWQhIH1cclxuICB9KTtcclxuXHJcbiAgY29uc3QgZ3JhZGVEYXRhID0ge1xyXG4gICAgc2NvcmU6IGZpbmFsU2NvcmUsXHJcbiAgICBzdGF0dXM6ICdSRUNPTU1FTkRFRCcgYXMgY29uc3QsXHJcbiAgICBncmFkZWRCeUFJOiB0cnVlLFxyXG4gICAgbm90ZXM6ICdBdXRvLWdyYWRlZCBNQ1EnLFxyXG4gICAgYnJlYWtkb3duSnNvbjogSlNPTi5zdHJpbmdpZnkocHJvY2Vzc2VkQW5zd2VycyksXHJcbiAgfTtcclxuXHJcbiAgaWYgKGV4aXN0aW5nR3JhZGUpIHtcclxuICAgIGF3YWl0IHByaXNtYS5ncmFkZS51cGRhdGUoe1xyXG4gICAgICB3aGVyZTogeyBpZDogZXhpc3RpbmdHcmFkZS5pZCB9LFxyXG4gICAgICBkYXRhOiBncmFkZURhdGEsXHJcbiAgICB9KTtcclxuICB9IGVsc2Uge1xyXG4gICAgYXdhaXQgcHJpc21hLmdyYWRlLmNyZWF0ZSh7XHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBzdWJtaXNzaW9uOiB7IGNvbm5lY3Q6IHsgaWQ6IHN1Ym1pc3Npb25JZCEgfSB9LFxyXG4gICAgICAgIC4uLmdyYWRlRGF0YSxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICBzY29yZTogZmluYWxTY29yZSxcclxuICAgIHRvdGFsOiAxMDAsXHJcbiAgICBwb2ludHNFYXJuZWQ6IGVhcm5lZFBvaW50cyxcclxuICAgIG1heFBvaW50czogdG90YWxQb2ludHNcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3VibWl0Q29kZSh0YXNrSWQ6IHN0cmluZywgcXVlc3Rpb25JZDogc3RyaW5nLCBjb2RlOiBzdHJpbmcsIGxpdmVTZXNzaW9uSWQ/OiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXJ2ZXJTZXNzaW9uKGF1dGhPcHRpb25zKTtcclxuICAgIGlmICghc2Vzc2lvbikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuICBcclxuICAgIGNvbnN0IHF1ZXN0aW9uID0gYXdhaXQgcHJpc21hLnF1ZXN0aW9uLmZpbmRVbmlxdWUoe1xyXG4gICAgICAgIHdoZXJlOiB7IGlkOiBxdWVzdGlvbklkIH0sXHJcbiAgICAgICAgaW5jbHVkZTogeyBhbnN3ZXJLZXk6IHRydWUgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKCFxdWVzdGlvbikgdGhyb3cgbmV3IEVycm9yKCdRdWVzdGlvbiBub3QgZm91bmQnKTtcclxuXHJcbiAgICAvLyBDcmVhdGUvVXBkYXRlIFN1Ym1pc3Npb25cclxuICAgIC8vIENoZWNrIGlmIGRyYWZ0IGV4aXN0cz9cclxuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgcHJpc21hLnN1Ym1pc3Npb24uZmluZEZpcnN0KHtcclxuICAgICAgICB3aGVyZToge1xyXG4gICAgICAgICAgICB0YXNrSWQsXHJcbiAgICAgICAgICAgIHF1ZXN0aW9uSWQsXHJcbiAgICAgICAgICAgIHN0dWRlbnRJZDogc2Vzc2lvbi51c2VyLmlkXHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgbGV0IHN1Ym1pc3Npb25JZCA9IGV4aXN0aW5nPy5pZDtcclxuXHJcbiAgICBpZiAoZXhpc3RpbmcpIHtcclxuICAgICAgICBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi51cGRhdGUoe1xyXG4gICAgICAgICAgICB3aGVyZTogeyBpZDogZXhpc3RpbmcuaWQgfSxcclxuICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgY29udGVudFRleHQ6IGNvZGUsXHJcbiAgICAgICAgICAgICAgICBzdGF0dXM6ICdTVUJNSVRURUQnLFxyXG4gICAgICAgICAgICAgICAgc3VibWl0dGVkQXQ6IG5ldyBEYXRlKCksXHJcbiAgICAgICAgICAgICAgICBsaXZlU2Vzc2lvbklkIC8vIFVwZGF0ZSBzZXNzaW9uIElEIGlmIG5lZWRlZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IHN1YiA9IGF3YWl0IHByaXNtYS5zdWJtaXNzaW9uLmNyZWF0ZSh7XHJcbiAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uSWQsXHJcbiAgICAgICAgICAgICAgICBzdHVkZW50SWQ6IHNlc3Npb24udXNlci5pZCxcclxuICAgICAgICAgICAgICAgIGxpdmVTZXNzaW9uSWQsXHJcbiAgICAgICAgICAgICAgICBjb250ZW50VGV4dDogY29kZSxcclxuICAgICAgICAgICAgICAgIHN0YXR1czogJ1NVQk1JVFRFRCcsXHJcbiAgICAgICAgICAgICAgICBzdWJtaXR0ZWRBdDogbmV3IERhdGUoKSxcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHN1Ym1pc3Npb25JZCA9IHN1Yi5pZDtcclxuICAgIH1cclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL2xpdmUnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwbG9hZEV2aWRlbmNlKGZvcm1EYXRhOiBGb3JtRGF0YSkge1xyXG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGdldFNlcnZlclNlc3Npb24oYXV0aE9wdGlvbnMpO1xyXG4gICAgaWYgKCFzZXNzaW9uKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xyXG5cclxuICAgIGNvbnN0IGZpbGUgPSBmb3JtRGF0YS5nZXQoJ2ZpbGUnKSBhcyBGaWxlO1xyXG4gICAgY29uc3QgdGFza0lkID0gZm9ybURhdGEuZ2V0KCd0YXNrSWQnKSBhcyBzdHJpbmc7XHJcbiAgICBjb25zdCBsaXZlU2Vzc2lvbklkID0gZm9ybURhdGEuZ2V0KCdsaXZlU2Vzc2lvbklkJykgYXMgc3RyaW5nO1xyXG5cclxuICAgIGlmICghZmlsZSB8fCAhdGFza0lkKSB0aHJvdyBuZXcgRXJyb3IoJ01pc3NpbmcgcmVxdWlyZWQgZmllbGRzJyk7XHJcblxyXG4gICAgLy8gVmFsaWRhdGUgZmlsZVxyXG4gICAgaWYgKGZpbGUuc2l6ZSA9PT0gMCkge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignRmlsZSBpcyBlbXB0eScpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChmaWxlLnNpemUgPiAxMCAqIDEwMjQgKiAxMDI0KSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGaWxlIHNpemUgbXVzdCBiZSBsZXNzIHRoYW4gMTBNQicpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIENvbnZlcnQgdG8gQnVmZmVyXHJcbiAgICBjb25zdCBidWZmZXIgPSBCdWZmZXIuZnJvbShhd2FpdCBmaWxlLmFycmF5QnVmZmVyKCkpO1xyXG4gICAgY29uc3QgcGF0aCA9IGAke3Nlc3Npb24udXNlci5pZH0vJHt0YXNrSWR9LyR7RGF0ZS5ub3coKX0tJHtmaWxlLm5hbWV9YDtcclxuXHJcbiAgICAvLyBVcGxvYWQgdG8gJ2V2aWRlbmNlJyBidWNrZXQgKHByaXZhdGUpXHJcbiAgICBjb25zdCB7IHBhdGg6IHN0b3JhZ2VQYXRoIH0gPSBhd2FpdCB1cGxvYWRGaWxlKCdldmlkZW5jZScsIHBhdGgsIGJ1ZmZlciwge1xyXG4gICAgICAgIGNvbnRlbnRUeXBlOiBmaWxlLnR5cGUsXHJcbiAgICAgICAgdXBzZXJ0OiB0cnVlXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBUcnkgdG8gZmluZCBleGlzdGluZyBjb2RlIHN1Ym1pc3Npb24gZmlyc3RcclxuICAgIC8vIFByaW9yaXR5IDE6IEZpbmQgYnkgbGl2ZVNlc3Npb25JZCBhbmQgcXVlc3Rpb25JZCAobW9zdCBzcGVjaWZpYylcclxuICAgIGxldCBjb2RlU3VibWlzc2lvbiA9IGxpdmVTZXNzaW9uSWQgPyBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi5maW5kRmlyc3Qoe1xyXG4gICAgICAgIHdoZXJlOiB7XHJcbiAgICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgICAgc3R1ZGVudElkOiBzZXNzaW9uLnVzZXIuaWQsXHJcbiAgICAgICAgICAgIGxpdmVTZXNzaW9uSWQsXHJcbiAgICAgICAgICAgIHF1ZXN0aW9uSWQ6IHsgbm90OiBudWxsIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIG9yZGVyQnk6IHsgY3JlYXRlZEF0OiAnZGVzYycgfVxyXG4gICAgfSkgOiBudWxsO1xyXG5cclxuICAgIC8vIFByaW9yaXR5IDI6IEZpbmQgYW55IHN1Ym1pc3Npb24gd2l0aCBxdWVzdGlvbklkIGZvciB0aGlzIHRhc2tcclxuICAgIGlmICghY29kZVN1Ym1pc3Npb24pIHtcclxuICAgICAgICBjb2RlU3VibWlzc2lvbiA9IGF3YWl0IHByaXNtYS5zdWJtaXNzaW9uLmZpbmRGaXJzdCh7XHJcbiAgICAgICAgICAgIHdoZXJlOiB7XHJcbiAgICAgICAgICAgICAgICB0YXNrSWQsXHJcbiAgICAgICAgICAgICAgICBzdHVkZW50SWQ6IHNlc3Npb24udXNlci5pZCxcclxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uSWQ6IHsgbm90OiBudWxsIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgb3JkZXJCeTogeyBjcmVhdGVkQXQ6ICdkZXNjJyB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGNvZGVTdWJtaXNzaW9uKSB7XHJcbiAgICAgICAgLy8gQXR0YWNoIFBERiB0byBleGlzdGluZyBjb2RlIHN1Ym1pc3Npb25cclxuICAgICAgICBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi51cGRhdGUoe1xyXG4gICAgICAgICAgICB3aGVyZTogeyBpZDogY29kZVN1Ym1pc3Npb24uaWQgfSxcclxuICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgZXZpZGVuY2VQZGZQYXRoOiBzdG9yYWdlUGF0aCxcclxuICAgICAgICAgICAgICAgIGxpdmVTZXNzaW9uSWQ6IGxpdmVTZXNzaW9uSWQgfHwgY29kZVN1Ym1pc3Npb24ubGl2ZVNlc3Npb25JZCxcclxuICAgICAgICAgICAgICAgIHN0YXR1czogJ1NVQk1JVFRFRCcsXHJcbiAgICAgICAgICAgICAgICBzdWJtaXR0ZWRBdDogY29kZVN1Ym1pc3Npb24uc3VibWl0dGVkQXQgfHwgbmV3IERhdGUoKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIE5vIGNvZGUgc3VibWlzc2lvbiBmb3VuZCAtIHRoaXMgc2hvdWxkbid0IG5vcm1hbGx5IGhhcHBlbiBmb3IgSlVSTkFMIHRhc2tzXHJcbiAgICAgICAgLy8gQ3JlYXRlIG1pbmltYWwgc3VibWlzc2lvbiB3aXRoIGp1c3QgdGhlIFBERlxyXG4gICAgICAgIGF3YWl0IHByaXNtYS5zdWJtaXNzaW9uLmNyZWF0ZSh7XHJcbiAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgICAgICAgIHN0dWRlbnRJZDogc2Vzc2lvbi51c2VyLmlkLFxyXG4gICAgICAgICAgICAgICAgbGl2ZVNlc3Npb25JZCxcclxuICAgICAgICAgICAgICAgIGV2aWRlbmNlUGRmUGF0aDogc3RvcmFnZVBhdGgsXHJcbiAgICAgICAgICAgICAgICBzdGF0dXM6ICdTVUJNSVRURUQnLFxyXG4gICAgICAgICAgICAgICAgc3VibWl0dGVkQXQ6IG5ldyBEYXRlKClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL2FzaXN0ZW4vZ3JhZGluZycpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiNFJBUXNCIn0=
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:a1d757 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"7896dc8c36009457217fe228bec169f5747f0052d9":"submitCode"},"app/actions/submission.ts",""] */ __turbopack_context__.s([
    "submitCode",
    ()=>submitCode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var submitCode = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("7896dc8c36009457217fe228bec169f5747f0052d9", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "submitCode"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vc3VibWlzc2lvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcic7XHJcblxyXG5pbXBvcnQgeyBwcmlzbWEgfSBmcm9tICdAL2xpYi9wcmlzbWEnO1xyXG5pbXBvcnQgeyBnZXRTZXJ2ZXJTZXNzaW9uIH0gZnJvbSAnbmV4dC1hdXRoJztcclxuaW1wb3J0IHsgYXV0aE9wdGlvbnMgfSBmcm9tICdAL2xpYi9hdXRoJztcclxuaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tICduZXh0L2NhY2hlJztcclxuaW1wb3J0IHsgdXBsb2FkRmlsZSB9IGZyb20gJ0AvbGliL3N1cGFiYXNlJztcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzdWJtaXRNQ1EodGFza0lkOiBzdHJpbmcsIGFuc3dlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4sIGxpdmVTZXNzaW9uSWQ/OiBzdHJpbmcpIHtcclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2VydmVyU2Vzc2lvbihhdXRoT3B0aW9ucyk7XHJcbiAgaWYgKCFzZXNzaW9uKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xyXG5cclxuICBjb25zdCB0YXNrID0gYXdhaXQgcHJpc21hLnRhc2suZmluZFVuaXF1ZSh7XHJcbiAgICB3aGVyZTogeyBpZDogdGFza0lkIH0sXHJcbiAgICBpbmNsdWRlOiB7IHF1ZXN0aW9uczogeyBpbmNsdWRlOiB7IGFuc3dlcktleTogdHJ1ZSB9IH0gfVxyXG4gIH0pO1xyXG5cclxuICBpZiAoIXRhc2spIHRocm93IG5ldyBFcnJvcignVGFzayBub3QgZm91bmQnKTtcclxuXHJcbiAgLy8gQ2FsY3VsYXRlIHNjb3JlXHJcbiAgbGV0IHRvdGFsUG9pbnRzID0gMDtcclxuICBsZXQgZWFybmVkUG9pbnRzID0gMDtcclxuICBjb25zdCBwcm9jZXNzZWRBbnN3ZXJzOiBhbnlbXSA9IFtdO1xyXG5cclxuICBjb25zdCBub3JtYWxpemUgPSAodmFsdWU/OiBzdHJpbmcgfCBudWxsKSA9PiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IHZhbHVlLnRyaW0oKSA6ICcnKTtcclxuICBjb25zdCBwYXJzZU9wdGlvbnMgPSAob3B0aW9uc0pzb24/OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nW10gPT4ge1xyXG4gICAgICBpZiAoIW9wdGlvbnNKc29uKSByZXR1cm4gW107XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKG9wdGlvbnNKc29uKTtcclxuICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHBhcnNlZCkpIHtcclxuICAgICAgICAgICAgICByZXR1cm4gcGFyc2VkLm1hcCgob3B0KSA9PiAodHlwZW9mIG9wdCA9PT0gJ3N0cmluZycgPyBvcHQgOiBTdHJpbmcob3B0KSkpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgY29uc29sZS53YXJuKCdGYWlsZWQgdG8gcGFyc2Ugb3B0aW9ucyBKU09OJywgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBbXTtcclxuICB9O1xyXG5cclxuICBmb3IgKGNvbnN0IHF1ZXN0aW9uIG9mIHRhc2sucXVlc3Rpb25zKSB7XHJcbiAgICAgIGNvbnN0IHN0dWRlbnRBbnN3ZXIgPSBub3JtYWxpemUoYW5zd2Vyc1txdWVzdGlvbi5pZF0pO1xyXG4gICAgICBjb25zdCBwb2ludHMgPSBxdWVzdGlvbi5wb2ludHMgfHwgMTA7IC8vIERlZmF1bHQgcG9pbnRzIGlmIG5vdCBzZXRcclxuICAgICAgdG90YWxQb2ludHMgKz0gcG9pbnRzO1xyXG5cclxuICAgICAgaWYgKHN0dWRlbnRBbnN3ZXIpIHtcclxuICAgICAgICAgIGNvbnN0IHJhd0Fuc3dlcktleSA9IG5vcm1hbGl6ZShxdWVzdGlvbi5hbnN3ZXJLZXk/LmNvcnJlY3RBbnN3ZXIpO1xyXG4gICAgICAgICAgbGV0IGlzQ29ycmVjdCA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgIGlmIChyYXdBbnN3ZXJLZXkpIHtcclxuICAgICAgICAgICAgICAvLyBQcmltYXJ5OiBjb21wYXJlIHJhdyBzdHJpbmdzIChjb3ZlcnMgbnVtZXJpYyBpbmRleGVzIHN0b3JlZCBhcyBzdHJpbmdzKVxyXG4gICAgICAgICAgICAgIGlmIChyYXdBbnN3ZXJLZXkgPT09IHN0dWRlbnRBbnN3ZXIpIHtcclxuICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBvcHRpb25zID0gcGFyc2VPcHRpb25zKHF1ZXN0aW9uLm9wdGlvbnNKc29uKTtcclxuICAgICAgICAgICAgICAgICAgY29uc3Qgc3R1ZGVudEluZGV4ID0gTnVtYmVyKHN0dWRlbnRBbnN3ZXIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgLy8gSWYgYW5zd2VyIGtleSBzdG9yZWQgYXMgb3B0aW9uIHRleHQsIGNvbXBhcmUgc2VsZWN0ZWQgb3B0aW9uIHRleHRcclxuICAgICAgICAgICAgICAgICAgaWYgKCFOdW1iZXIuaXNOYU4oc3R1ZGVudEluZGV4KSAmJiBvcHRpb25zW3N0dWRlbnRJbmRleF0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkT3B0aW9uID0gbm9ybWFsaXplKG9wdGlvbnNbc3R1ZGVudEluZGV4XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZWN0ZWRPcHRpb24gJiYgc2VsZWN0ZWRPcHRpb24udG9Mb3dlckNhc2UoKSA9PT0gcmF3QW5zd2VyS2V5LnRvTG93ZXJDYXNlKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3QgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAvLyBJZiBhbnN3ZXIga2V5IHN0b3JlZCBhcyBsZXR0ZXIgKEEsIEIsIEMuLi4pLCBtYXAgdG8gaW5kZXhcclxuICAgICAgICAgICAgICAgICAgaWYgKCFpc0NvcnJlY3QgJiYgL15bQS1aYS16XSQvLnRlc3QocmF3QW5zd2VyS2V5KSAmJiAhTnVtYmVyLmlzTmFOKHN0dWRlbnRJbmRleCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxldHRlckluZGV4ID0gcmF3QW5zd2VyS2V5LnRvVXBwZXJDYXNlKCkuY2hhckNvZGVBdCgwKSAtIDY1O1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGxldHRlckluZGV4ID09PSBzdHVkZW50SW5kZXgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3QgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGlmIChpc0NvcnJlY3QpIHtcclxuICAgICAgICAgICAgICBlYXJuZWRQb2ludHMgKz0gcG9pbnRzO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBwcm9jZXNzZWRBbnN3ZXJzLnB1c2goe1xyXG4gICAgICAgICAgICAgIHF1ZXN0aW9uSWQ6IHF1ZXN0aW9uLmlkLFxyXG4gICAgICAgICAgICAgIGFuc3dlcjogc3R1ZGVudEFuc3dlcixcclxuICAgICAgICAgICAgICBpc0NvcnJlY3RcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBmaW5hbFNjb3JlID0gdG90YWxQb2ludHMgPiAwID8gKGVhcm5lZFBvaW50cyAvIHRvdGFsUG9pbnRzKSAqIDEwMCA6IDA7XHJcblxyXG4gIC8vIENoZWNrIGZvciBleGlzdGluZyBzdWJtaXNzaW9uIGZvciB0aGlzIFRBU0sgKG5vdCBwZXIgcXVlc3Rpb24pXHJcbiAgY29uc3QgZXhpc3RpbmdTdWJtaXNzaW9uID0gYXdhaXQgcHJpc21hLnN1Ym1pc3Npb24uZmluZEZpcnN0KHtcclxuICAgICAgd2hlcmU6IHtcclxuICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgIHN0dWRlbnRJZDogc2Vzc2lvbi51c2VyLmlkLFxyXG4gICAgICAgICAgcXVlc3Rpb25JZDogbnVsbCAvLyBUYXNrLWxldmVsIHN1Ym1pc3Npb25cclxuICAgICAgfVxyXG4gIH0pO1xyXG5cclxuICBsZXQgc3VibWlzc2lvbklkID0gZXhpc3RpbmdTdWJtaXNzaW9uPy5pZDtcclxuXHJcbiAgaWYgKGV4aXN0aW5nU3VibWlzc2lvbikge1xyXG4gICAgICBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi51cGRhdGUoe1xyXG4gICAgICAgICAgd2hlcmU6IHsgaWQ6IGV4aXN0aW5nU3VibWlzc2lvbi5pZCB9LFxyXG4gICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgIGFuc3dlcnNKc29uOiBKU09OLnN0cmluZ2lmeShwcm9jZXNzZWRBbnN3ZXJzKSxcclxuICAgICAgICAgICAgICBzdGF0dXM6ICdHUkFERUQnLFxyXG4gICAgICAgICAgICAgIHN1Ym1pdHRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICAgICAgICAgIGxpdmVTZXNzaW9uSWRcclxuICAgICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgfSBlbHNlIHtcclxuICAgICAgY29uc3Qgc3ViID0gYXdhaXQgcHJpc21hLnN1Ym1pc3Npb24uY3JlYXRlKHtcclxuICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICB0YXNrSWQsXHJcbiAgICAgICAgICAgICAgc3R1ZGVudElkOiBzZXNzaW9uLnVzZXIuaWQsXHJcbiAgICAgICAgICAgICAgbGl2ZVNlc3Npb25JZCxcclxuICAgICAgICAgICAgICBhbnN3ZXJzSnNvbjogSlNPTi5zdHJpbmdpZnkocHJvY2Vzc2VkQW5zd2VycyksXHJcbiAgICAgICAgICAgICAgc3RhdHVzOiAnR1JBREVEJyxcclxuICAgICAgICAgICAgICBzdWJtaXR0ZWRBdDogbmV3IERhdGUoKSxcclxuICAgICAgICAgICAgICBxdWVzdGlvbklkOiBudWxsXHJcbiAgICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICBzdWJtaXNzaW9uSWQgPSBzdWIuaWQ7XHJcbiAgfVxyXG5cclxuICAvLyBDcmVhdGUgb3IgVXBkYXRlIEdyYWRlIGltbWVkaWF0ZWx5XHJcbiAgY29uc3QgZXhpc3RpbmdHcmFkZSA9IGF3YWl0IHByaXNtYS5ncmFkZS5maW5kVW5pcXVlKHtcclxuICAgICAgd2hlcmU6IHsgc3VibWlzc2lvbklkOiBzdWJtaXNzaW9uSWQhIH1cclxuICB9KTtcclxuXHJcbiAgY29uc3QgZ3JhZGVEYXRhID0ge1xyXG4gICAgc2NvcmU6IGZpbmFsU2NvcmUsXHJcbiAgICBzdGF0dXM6ICdSRUNPTU1FTkRFRCcgYXMgY29uc3QsXHJcbiAgICBncmFkZWRCeUFJOiB0cnVlLFxyXG4gICAgbm90ZXM6ICdBdXRvLWdyYWRlZCBNQ1EnLFxyXG4gICAgYnJlYWtkb3duSnNvbjogSlNPTi5zdHJpbmdpZnkocHJvY2Vzc2VkQW5zd2VycyksXHJcbiAgfTtcclxuXHJcbiAgaWYgKGV4aXN0aW5nR3JhZGUpIHtcclxuICAgIGF3YWl0IHByaXNtYS5ncmFkZS51cGRhdGUoe1xyXG4gICAgICB3aGVyZTogeyBpZDogZXhpc3RpbmdHcmFkZS5pZCB9LFxyXG4gICAgICBkYXRhOiBncmFkZURhdGEsXHJcbiAgICB9KTtcclxuICB9IGVsc2Uge1xyXG4gICAgYXdhaXQgcHJpc21hLmdyYWRlLmNyZWF0ZSh7XHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBzdWJtaXNzaW9uOiB7IGNvbm5lY3Q6IHsgaWQ6IHN1Ym1pc3Npb25JZCEgfSB9LFxyXG4gICAgICAgIC4uLmdyYWRlRGF0YSxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICBzY29yZTogZmluYWxTY29yZSxcclxuICAgIHRvdGFsOiAxMDAsXHJcbiAgICBwb2ludHNFYXJuZWQ6IGVhcm5lZFBvaW50cyxcclxuICAgIG1heFBvaW50czogdG90YWxQb2ludHNcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3VibWl0Q29kZSh0YXNrSWQ6IHN0cmluZywgcXVlc3Rpb25JZDogc3RyaW5nLCBjb2RlOiBzdHJpbmcsIGxpdmVTZXNzaW9uSWQ/OiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXJ2ZXJTZXNzaW9uKGF1dGhPcHRpb25zKTtcclxuICAgIGlmICghc2Vzc2lvbikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuICBcclxuICAgIGNvbnN0IHF1ZXN0aW9uID0gYXdhaXQgcHJpc21hLnF1ZXN0aW9uLmZpbmRVbmlxdWUoe1xyXG4gICAgICAgIHdoZXJlOiB7IGlkOiBxdWVzdGlvbklkIH0sXHJcbiAgICAgICAgaW5jbHVkZTogeyBhbnN3ZXJLZXk6IHRydWUgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKCFxdWVzdGlvbikgdGhyb3cgbmV3IEVycm9yKCdRdWVzdGlvbiBub3QgZm91bmQnKTtcclxuXHJcbiAgICAvLyBDcmVhdGUvVXBkYXRlIFN1Ym1pc3Npb25cclxuICAgIC8vIENoZWNrIGlmIGRyYWZ0IGV4aXN0cz9cclxuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgcHJpc21hLnN1Ym1pc3Npb24uZmluZEZpcnN0KHtcclxuICAgICAgICB3aGVyZToge1xyXG4gICAgICAgICAgICB0YXNrSWQsXHJcbiAgICAgICAgICAgIHF1ZXN0aW9uSWQsXHJcbiAgICAgICAgICAgIHN0dWRlbnRJZDogc2Vzc2lvbi51c2VyLmlkXHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgbGV0IHN1Ym1pc3Npb25JZCA9IGV4aXN0aW5nPy5pZDtcclxuXHJcbiAgICBpZiAoZXhpc3RpbmcpIHtcclxuICAgICAgICBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi51cGRhdGUoe1xyXG4gICAgICAgICAgICB3aGVyZTogeyBpZDogZXhpc3RpbmcuaWQgfSxcclxuICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgY29udGVudFRleHQ6IGNvZGUsXHJcbiAgICAgICAgICAgICAgICBzdGF0dXM6ICdTVUJNSVRURUQnLFxyXG4gICAgICAgICAgICAgICAgc3VibWl0dGVkQXQ6IG5ldyBEYXRlKCksXHJcbiAgICAgICAgICAgICAgICBsaXZlU2Vzc2lvbklkIC8vIFVwZGF0ZSBzZXNzaW9uIElEIGlmIG5lZWRlZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IHN1YiA9IGF3YWl0IHByaXNtYS5zdWJtaXNzaW9uLmNyZWF0ZSh7XHJcbiAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uSWQsXHJcbiAgICAgICAgICAgICAgICBzdHVkZW50SWQ6IHNlc3Npb24udXNlci5pZCxcclxuICAgICAgICAgICAgICAgIGxpdmVTZXNzaW9uSWQsXHJcbiAgICAgICAgICAgICAgICBjb250ZW50VGV4dDogY29kZSxcclxuICAgICAgICAgICAgICAgIHN0YXR1czogJ1NVQk1JVFRFRCcsXHJcbiAgICAgICAgICAgICAgICBzdWJtaXR0ZWRBdDogbmV3IERhdGUoKSxcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHN1Ym1pc3Npb25JZCA9IHN1Yi5pZDtcclxuICAgIH1cclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL2xpdmUnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwbG9hZEV2aWRlbmNlKGZvcm1EYXRhOiBGb3JtRGF0YSkge1xyXG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGdldFNlcnZlclNlc3Npb24oYXV0aE9wdGlvbnMpO1xyXG4gICAgaWYgKCFzZXNzaW9uKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xyXG5cclxuICAgIGNvbnN0IGZpbGUgPSBmb3JtRGF0YS5nZXQoJ2ZpbGUnKSBhcyBGaWxlO1xyXG4gICAgY29uc3QgdGFza0lkID0gZm9ybURhdGEuZ2V0KCd0YXNrSWQnKSBhcyBzdHJpbmc7XHJcbiAgICBjb25zdCBsaXZlU2Vzc2lvbklkID0gZm9ybURhdGEuZ2V0KCdsaXZlU2Vzc2lvbklkJykgYXMgc3RyaW5nO1xyXG5cclxuICAgIGlmICghZmlsZSB8fCAhdGFza0lkKSB0aHJvdyBuZXcgRXJyb3IoJ01pc3NpbmcgcmVxdWlyZWQgZmllbGRzJyk7XHJcblxyXG4gICAgLy8gVmFsaWRhdGUgZmlsZVxyXG4gICAgaWYgKGZpbGUuc2l6ZSA9PT0gMCkge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignRmlsZSBpcyBlbXB0eScpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChmaWxlLnNpemUgPiAxMCAqIDEwMjQgKiAxMDI0KSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGaWxlIHNpemUgbXVzdCBiZSBsZXNzIHRoYW4gMTBNQicpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIENvbnZlcnQgdG8gQnVmZmVyXHJcbiAgICBjb25zdCBidWZmZXIgPSBCdWZmZXIuZnJvbShhd2FpdCBmaWxlLmFycmF5QnVmZmVyKCkpO1xyXG4gICAgY29uc3QgcGF0aCA9IGAke3Nlc3Npb24udXNlci5pZH0vJHt0YXNrSWR9LyR7RGF0ZS5ub3coKX0tJHtmaWxlLm5hbWV9YDtcclxuXHJcbiAgICAvLyBVcGxvYWQgdG8gJ2V2aWRlbmNlJyBidWNrZXQgKHByaXZhdGUpXHJcbiAgICBjb25zdCB7IHBhdGg6IHN0b3JhZ2VQYXRoIH0gPSBhd2FpdCB1cGxvYWRGaWxlKCdldmlkZW5jZScsIHBhdGgsIGJ1ZmZlciwge1xyXG4gICAgICAgIGNvbnRlbnRUeXBlOiBmaWxlLnR5cGUsXHJcbiAgICAgICAgdXBzZXJ0OiB0cnVlXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBUcnkgdG8gZmluZCBleGlzdGluZyBjb2RlIHN1Ym1pc3Npb24gZmlyc3RcclxuICAgIC8vIFByaW9yaXR5IDE6IEZpbmQgYnkgbGl2ZVNlc3Npb25JZCBhbmQgcXVlc3Rpb25JZCAobW9zdCBzcGVjaWZpYylcclxuICAgIGxldCBjb2RlU3VibWlzc2lvbiA9IGxpdmVTZXNzaW9uSWQgPyBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi5maW5kRmlyc3Qoe1xyXG4gICAgICAgIHdoZXJlOiB7XHJcbiAgICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgICAgc3R1ZGVudElkOiBzZXNzaW9uLnVzZXIuaWQsXHJcbiAgICAgICAgICAgIGxpdmVTZXNzaW9uSWQsXHJcbiAgICAgICAgICAgIHF1ZXN0aW9uSWQ6IHsgbm90OiBudWxsIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIG9yZGVyQnk6IHsgY3JlYXRlZEF0OiAnZGVzYycgfVxyXG4gICAgfSkgOiBudWxsO1xyXG5cclxuICAgIC8vIFByaW9yaXR5IDI6IEZpbmQgYW55IHN1Ym1pc3Npb24gd2l0aCBxdWVzdGlvbklkIGZvciB0aGlzIHRhc2tcclxuICAgIGlmICghY29kZVN1Ym1pc3Npb24pIHtcclxuICAgICAgICBjb2RlU3VibWlzc2lvbiA9IGF3YWl0IHByaXNtYS5zdWJtaXNzaW9uLmZpbmRGaXJzdCh7XHJcbiAgICAgICAgICAgIHdoZXJlOiB7XHJcbiAgICAgICAgICAgICAgICB0YXNrSWQsXHJcbiAgICAgICAgICAgICAgICBzdHVkZW50SWQ6IHNlc3Npb24udXNlci5pZCxcclxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uSWQ6IHsgbm90OiBudWxsIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgb3JkZXJCeTogeyBjcmVhdGVkQXQ6ICdkZXNjJyB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGNvZGVTdWJtaXNzaW9uKSB7XHJcbiAgICAgICAgLy8gQXR0YWNoIFBERiB0byBleGlzdGluZyBjb2RlIHN1Ym1pc3Npb25cclxuICAgICAgICBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi51cGRhdGUoe1xyXG4gICAgICAgICAgICB3aGVyZTogeyBpZDogY29kZVN1Ym1pc3Npb24uaWQgfSxcclxuICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgZXZpZGVuY2VQZGZQYXRoOiBzdG9yYWdlUGF0aCxcclxuICAgICAgICAgICAgICAgIGxpdmVTZXNzaW9uSWQ6IGxpdmVTZXNzaW9uSWQgfHwgY29kZVN1Ym1pc3Npb24ubGl2ZVNlc3Npb25JZCxcclxuICAgICAgICAgICAgICAgIHN0YXR1czogJ1NVQk1JVFRFRCcsXHJcbiAgICAgICAgICAgICAgICBzdWJtaXR0ZWRBdDogY29kZVN1Ym1pc3Npb24uc3VibWl0dGVkQXQgfHwgbmV3IERhdGUoKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIE5vIGNvZGUgc3VibWlzc2lvbiBmb3VuZCAtIHRoaXMgc2hvdWxkbid0IG5vcm1hbGx5IGhhcHBlbiBmb3IgSlVSTkFMIHRhc2tzXHJcbiAgICAgICAgLy8gQ3JlYXRlIG1pbmltYWwgc3VibWlzc2lvbiB3aXRoIGp1c3QgdGhlIFBERlxyXG4gICAgICAgIGF3YWl0IHByaXNtYS5zdWJtaXNzaW9uLmNyZWF0ZSh7XHJcbiAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgICAgICAgIHN0dWRlbnRJZDogc2Vzc2lvbi51c2VyLmlkLFxyXG4gICAgICAgICAgICAgICAgbGl2ZVNlc3Npb25JZCxcclxuICAgICAgICAgICAgICAgIGV2aWRlbmNlUGRmUGF0aDogc3RvcmFnZVBhdGgsXHJcbiAgICAgICAgICAgICAgICBzdGF0dXM6ICdTVUJNSVRURUQnLFxyXG4gICAgICAgICAgICAgICAgc3VibWl0dGVkQXQ6IG5ldyBEYXRlKClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL2FzaXN0ZW4vZ3JhZGluZycpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiNlJBK0pzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/actions/data:fb02fe [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"405f1363b4b4e6e6700fcd588b8618dfef8a0af854":"uploadEvidence"},"app/actions/submission.ts",""] */ __turbopack_context__.s([
    "uploadEvidence",
    ()=>uploadEvidence
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var uploadEvidence = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("405f1363b4b4e6e6700fcd588b8618dfef8a0af854", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "uploadEvidence"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vc3VibWlzc2lvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcic7XHJcblxyXG5pbXBvcnQgeyBwcmlzbWEgfSBmcm9tICdAL2xpYi9wcmlzbWEnO1xyXG5pbXBvcnQgeyBnZXRTZXJ2ZXJTZXNzaW9uIH0gZnJvbSAnbmV4dC1hdXRoJztcclxuaW1wb3J0IHsgYXV0aE9wdGlvbnMgfSBmcm9tICdAL2xpYi9hdXRoJztcclxuaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tICduZXh0L2NhY2hlJztcclxuaW1wb3J0IHsgdXBsb2FkRmlsZSB9IGZyb20gJ0AvbGliL3N1cGFiYXNlJztcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzdWJtaXRNQ1EodGFza0lkOiBzdHJpbmcsIGFuc3dlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4sIGxpdmVTZXNzaW9uSWQ/OiBzdHJpbmcpIHtcclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2VydmVyU2Vzc2lvbihhdXRoT3B0aW9ucyk7XHJcbiAgaWYgKCFzZXNzaW9uKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xyXG5cclxuICBjb25zdCB0YXNrID0gYXdhaXQgcHJpc21hLnRhc2suZmluZFVuaXF1ZSh7XHJcbiAgICB3aGVyZTogeyBpZDogdGFza0lkIH0sXHJcbiAgICBpbmNsdWRlOiB7IHF1ZXN0aW9uczogeyBpbmNsdWRlOiB7IGFuc3dlcktleTogdHJ1ZSB9IH0gfVxyXG4gIH0pO1xyXG5cclxuICBpZiAoIXRhc2spIHRocm93IG5ldyBFcnJvcignVGFzayBub3QgZm91bmQnKTtcclxuXHJcbiAgLy8gQ2FsY3VsYXRlIHNjb3JlXHJcbiAgbGV0IHRvdGFsUG9pbnRzID0gMDtcclxuICBsZXQgZWFybmVkUG9pbnRzID0gMDtcclxuICBjb25zdCBwcm9jZXNzZWRBbnN3ZXJzOiBhbnlbXSA9IFtdO1xyXG5cclxuICBjb25zdCBub3JtYWxpemUgPSAodmFsdWU/OiBzdHJpbmcgfCBudWxsKSA9PiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IHZhbHVlLnRyaW0oKSA6ICcnKTtcclxuICBjb25zdCBwYXJzZU9wdGlvbnMgPSAob3B0aW9uc0pzb24/OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nW10gPT4ge1xyXG4gICAgICBpZiAoIW9wdGlvbnNKc29uKSByZXR1cm4gW107XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKG9wdGlvbnNKc29uKTtcclxuICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHBhcnNlZCkpIHtcclxuICAgICAgICAgICAgICByZXR1cm4gcGFyc2VkLm1hcCgob3B0KSA9PiAodHlwZW9mIG9wdCA9PT0gJ3N0cmluZycgPyBvcHQgOiBTdHJpbmcob3B0KSkpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgY29uc29sZS53YXJuKCdGYWlsZWQgdG8gcGFyc2Ugb3B0aW9ucyBKU09OJywgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBbXTtcclxuICB9O1xyXG5cclxuICBmb3IgKGNvbnN0IHF1ZXN0aW9uIG9mIHRhc2sucXVlc3Rpb25zKSB7XHJcbiAgICAgIGNvbnN0IHN0dWRlbnRBbnN3ZXIgPSBub3JtYWxpemUoYW5zd2Vyc1txdWVzdGlvbi5pZF0pO1xyXG4gICAgICBjb25zdCBwb2ludHMgPSBxdWVzdGlvbi5wb2ludHMgfHwgMTA7IC8vIERlZmF1bHQgcG9pbnRzIGlmIG5vdCBzZXRcclxuICAgICAgdG90YWxQb2ludHMgKz0gcG9pbnRzO1xyXG5cclxuICAgICAgaWYgKHN0dWRlbnRBbnN3ZXIpIHtcclxuICAgICAgICAgIGNvbnN0IHJhd0Fuc3dlcktleSA9IG5vcm1hbGl6ZShxdWVzdGlvbi5hbnN3ZXJLZXk/LmNvcnJlY3RBbnN3ZXIpO1xyXG4gICAgICAgICAgbGV0IGlzQ29ycmVjdCA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgIGlmIChyYXdBbnN3ZXJLZXkpIHtcclxuICAgICAgICAgICAgICAvLyBQcmltYXJ5OiBjb21wYXJlIHJhdyBzdHJpbmdzIChjb3ZlcnMgbnVtZXJpYyBpbmRleGVzIHN0b3JlZCBhcyBzdHJpbmdzKVxyXG4gICAgICAgICAgICAgIGlmIChyYXdBbnN3ZXJLZXkgPT09IHN0dWRlbnRBbnN3ZXIpIHtcclxuICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBvcHRpb25zID0gcGFyc2VPcHRpb25zKHF1ZXN0aW9uLm9wdGlvbnNKc29uKTtcclxuICAgICAgICAgICAgICAgICAgY29uc3Qgc3R1ZGVudEluZGV4ID0gTnVtYmVyKHN0dWRlbnRBbnN3ZXIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgLy8gSWYgYW5zd2VyIGtleSBzdG9yZWQgYXMgb3B0aW9uIHRleHQsIGNvbXBhcmUgc2VsZWN0ZWQgb3B0aW9uIHRleHRcclxuICAgICAgICAgICAgICAgICAgaWYgKCFOdW1iZXIuaXNOYU4oc3R1ZGVudEluZGV4KSAmJiBvcHRpb25zW3N0dWRlbnRJbmRleF0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkT3B0aW9uID0gbm9ybWFsaXplKG9wdGlvbnNbc3R1ZGVudEluZGV4XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZWN0ZWRPcHRpb24gJiYgc2VsZWN0ZWRPcHRpb24udG9Mb3dlckNhc2UoKSA9PT0gcmF3QW5zd2VyS2V5LnRvTG93ZXJDYXNlKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3QgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAvLyBJZiBhbnN3ZXIga2V5IHN0b3JlZCBhcyBsZXR0ZXIgKEEsIEIsIEMuLi4pLCBtYXAgdG8gaW5kZXhcclxuICAgICAgICAgICAgICAgICAgaWYgKCFpc0NvcnJlY3QgJiYgL15bQS1aYS16XSQvLnRlc3QocmF3QW5zd2VyS2V5KSAmJiAhTnVtYmVyLmlzTmFOKHN0dWRlbnRJbmRleCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxldHRlckluZGV4ID0gcmF3QW5zd2VyS2V5LnRvVXBwZXJDYXNlKCkuY2hhckNvZGVBdCgwKSAtIDY1O1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGxldHRlckluZGV4ID09PSBzdHVkZW50SW5kZXgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvcnJlY3QgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGlmIChpc0NvcnJlY3QpIHtcclxuICAgICAgICAgICAgICBlYXJuZWRQb2ludHMgKz0gcG9pbnRzO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBwcm9jZXNzZWRBbnN3ZXJzLnB1c2goe1xyXG4gICAgICAgICAgICAgIHF1ZXN0aW9uSWQ6IHF1ZXN0aW9uLmlkLFxyXG4gICAgICAgICAgICAgIGFuc3dlcjogc3R1ZGVudEFuc3dlcixcclxuICAgICAgICAgICAgICBpc0NvcnJlY3RcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBmaW5hbFNjb3JlID0gdG90YWxQb2ludHMgPiAwID8gKGVhcm5lZFBvaW50cyAvIHRvdGFsUG9pbnRzKSAqIDEwMCA6IDA7XHJcblxyXG4gIC8vIENoZWNrIGZvciBleGlzdGluZyBzdWJtaXNzaW9uIGZvciB0aGlzIFRBU0sgKG5vdCBwZXIgcXVlc3Rpb24pXHJcbiAgY29uc3QgZXhpc3RpbmdTdWJtaXNzaW9uID0gYXdhaXQgcHJpc21hLnN1Ym1pc3Npb24uZmluZEZpcnN0KHtcclxuICAgICAgd2hlcmU6IHtcclxuICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgIHN0dWRlbnRJZDogc2Vzc2lvbi51c2VyLmlkLFxyXG4gICAgICAgICAgcXVlc3Rpb25JZDogbnVsbCAvLyBUYXNrLWxldmVsIHN1Ym1pc3Npb25cclxuICAgICAgfVxyXG4gIH0pO1xyXG5cclxuICBsZXQgc3VibWlzc2lvbklkID0gZXhpc3RpbmdTdWJtaXNzaW9uPy5pZDtcclxuXHJcbiAgaWYgKGV4aXN0aW5nU3VibWlzc2lvbikge1xyXG4gICAgICBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi51cGRhdGUoe1xyXG4gICAgICAgICAgd2hlcmU6IHsgaWQ6IGV4aXN0aW5nU3VibWlzc2lvbi5pZCB9LFxyXG4gICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgIGFuc3dlcnNKc29uOiBKU09OLnN0cmluZ2lmeShwcm9jZXNzZWRBbnN3ZXJzKSxcclxuICAgICAgICAgICAgICBzdGF0dXM6ICdHUkFERUQnLFxyXG4gICAgICAgICAgICAgIHN1Ym1pdHRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICAgICAgICAgIGxpdmVTZXNzaW9uSWRcclxuICAgICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgfSBlbHNlIHtcclxuICAgICAgY29uc3Qgc3ViID0gYXdhaXQgcHJpc21hLnN1Ym1pc3Npb24uY3JlYXRlKHtcclxuICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICB0YXNrSWQsXHJcbiAgICAgICAgICAgICAgc3R1ZGVudElkOiBzZXNzaW9uLnVzZXIuaWQsXHJcbiAgICAgICAgICAgICAgbGl2ZVNlc3Npb25JZCxcclxuICAgICAgICAgICAgICBhbnN3ZXJzSnNvbjogSlNPTi5zdHJpbmdpZnkocHJvY2Vzc2VkQW5zd2VycyksXHJcbiAgICAgICAgICAgICAgc3RhdHVzOiAnR1JBREVEJyxcclxuICAgICAgICAgICAgICBzdWJtaXR0ZWRBdDogbmV3IERhdGUoKSxcclxuICAgICAgICAgICAgICBxdWVzdGlvbklkOiBudWxsXHJcbiAgICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICBzdWJtaXNzaW9uSWQgPSBzdWIuaWQ7XHJcbiAgfVxyXG5cclxuICAvLyBDcmVhdGUgb3IgVXBkYXRlIEdyYWRlIGltbWVkaWF0ZWx5XHJcbiAgY29uc3QgZXhpc3RpbmdHcmFkZSA9IGF3YWl0IHByaXNtYS5ncmFkZS5maW5kVW5pcXVlKHtcclxuICAgICAgd2hlcmU6IHsgc3VibWlzc2lvbklkOiBzdWJtaXNzaW9uSWQhIH1cclxuICB9KTtcclxuXHJcbiAgY29uc3QgZ3JhZGVEYXRhID0ge1xyXG4gICAgc2NvcmU6IGZpbmFsU2NvcmUsXHJcbiAgICBzdGF0dXM6ICdSRUNPTU1FTkRFRCcgYXMgY29uc3QsXHJcbiAgICBncmFkZWRCeUFJOiB0cnVlLFxyXG4gICAgbm90ZXM6ICdBdXRvLWdyYWRlZCBNQ1EnLFxyXG4gICAgYnJlYWtkb3duSnNvbjogSlNPTi5zdHJpbmdpZnkocHJvY2Vzc2VkQW5zd2VycyksXHJcbiAgfTtcclxuXHJcbiAgaWYgKGV4aXN0aW5nR3JhZGUpIHtcclxuICAgIGF3YWl0IHByaXNtYS5ncmFkZS51cGRhdGUoe1xyXG4gICAgICB3aGVyZTogeyBpZDogZXhpc3RpbmdHcmFkZS5pZCB9LFxyXG4gICAgICBkYXRhOiBncmFkZURhdGEsXHJcbiAgICB9KTtcclxuICB9IGVsc2Uge1xyXG4gICAgYXdhaXQgcHJpc21hLmdyYWRlLmNyZWF0ZSh7XHJcbiAgICAgIGRhdGE6IHtcclxuICAgICAgICBzdWJtaXNzaW9uOiB7IGNvbm5lY3Q6IHsgaWQ6IHN1Ym1pc3Npb25JZCEgfSB9LFxyXG4gICAgICAgIC4uLmdyYWRlRGF0YSxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICBzY29yZTogZmluYWxTY29yZSxcclxuICAgIHRvdGFsOiAxMDAsXHJcbiAgICBwb2ludHNFYXJuZWQ6IGVhcm5lZFBvaW50cyxcclxuICAgIG1heFBvaW50czogdG90YWxQb2ludHNcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3VibWl0Q29kZSh0YXNrSWQ6IHN0cmluZywgcXVlc3Rpb25JZDogc3RyaW5nLCBjb2RlOiBzdHJpbmcsIGxpdmVTZXNzaW9uSWQ/OiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXJ2ZXJTZXNzaW9uKGF1dGhPcHRpb25zKTtcclxuICAgIGlmICghc2Vzc2lvbikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKTtcclxuICBcclxuICAgIGNvbnN0IHF1ZXN0aW9uID0gYXdhaXQgcHJpc21hLnF1ZXN0aW9uLmZpbmRVbmlxdWUoe1xyXG4gICAgICAgIHdoZXJlOiB7IGlkOiBxdWVzdGlvbklkIH0sXHJcbiAgICAgICAgaW5jbHVkZTogeyBhbnN3ZXJLZXk6IHRydWUgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKCFxdWVzdGlvbikgdGhyb3cgbmV3IEVycm9yKCdRdWVzdGlvbiBub3QgZm91bmQnKTtcclxuXHJcbiAgICAvLyBDcmVhdGUvVXBkYXRlIFN1Ym1pc3Npb25cclxuICAgIC8vIENoZWNrIGlmIGRyYWZ0IGV4aXN0cz9cclxuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgcHJpc21hLnN1Ym1pc3Npb24uZmluZEZpcnN0KHtcclxuICAgICAgICB3aGVyZToge1xyXG4gICAgICAgICAgICB0YXNrSWQsXHJcbiAgICAgICAgICAgIHF1ZXN0aW9uSWQsXHJcbiAgICAgICAgICAgIHN0dWRlbnRJZDogc2Vzc2lvbi51c2VyLmlkXHJcbiAgICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgbGV0IHN1Ym1pc3Npb25JZCA9IGV4aXN0aW5nPy5pZDtcclxuXHJcbiAgICBpZiAoZXhpc3RpbmcpIHtcclxuICAgICAgICBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi51cGRhdGUoe1xyXG4gICAgICAgICAgICB3aGVyZTogeyBpZDogZXhpc3RpbmcuaWQgfSxcclxuICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgY29udGVudFRleHQ6IGNvZGUsXHJcbiAgICAgICAgICAgICAgICBzdGF0dXM6ICdTVUJNSVRURUQnLFxyXG4gICAgICAgICAgICAgICAgc3VibWl0dGVkQXQ6IG5ldyBEYXRlKCksXHJcbiAgICAgICAgICAgICAgICBsaXZlU2Vzc2lvbklkIC8vIFVwZGF0ZSBzZXNzaW9uIElEIGlmIG5lZWRlZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IHN1YiA9IGF3YWl0IHByaXNtYS5zdWJtaXNzaW9uLmNyZWF0ZSh7XHJcbiAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uSWQsXHJcbiAgICAgICAgICAgICAgICBzdHVkZW50SWQ6IHNlc3Npb24udXNlci5pZCxcclxuICAgICAgICAgICAgICAgIGxpdmVTZXNzaW9uSWQsXHJcbiAgICAgICAgICAgICAgICBjb250ZW50VGV4dDogY29kZSxcclxuICAgICAgICAgICAgICAgIHN0YXR1czogJ1NVQk1JVFRFRCcsXHJcbiAgICAgICAgICAgICAgICBzdWJtaXR0ZWRBdDogbmV3IERhdGUoKSxcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHN1Ym1pc3Npb25JZCA9IHN1Yi5pZDtcclxuICAgIH1cclxuXHJcbiAgICByZXZhbGlkYXRlUGF0aCgnL2xpdmUnKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwbG9hZEV2aWRlbmNlKGZvcm1EYXRhOiBGb3JtRGF0YSkge1xyXG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGdldFNlcnZlclNlc3Npb24oYXV0aE9wdGlvbnMpO1xyXG4gICAgaWYgKCFzZXNzaW9uKSB0aHJvdyBuZXcgRXJyb3IoJ1VuYXV0aG9yaXplZCcpO1xyXG5cclxuICAgIGNvbnN0IGZpbGUgPSBmb3JtRGF0YS5nZXQoJ2ZpbGUnKSBhcyBGaWxlO1xyXG4gICAgY29uc3QgdGFza0lkID0gZm9ybURhdGEuZ2V0KCd0YXNrSWQnKSBhcyBzdHJpbmc7XHJcbiAgICBjb25zdCBsaXZlU2Vzc2lvbklkID0gZm9ybURhdGEuZ2V0KCdsaXZlU2Vzc2lvbklkJykgYXMgc3RyaW5nO1xyXG5cclxuICAgIGlmICghZmlsZSB8fCAhdGFza0lkKSB0aHJvdyBuZXcgRXJyb3IoJ01pc3NpbmcgcmVxdWlyZWQgZmllbGRzJyk7XHJcblxyXG4gICAgLy8gVmFsaWRhdGUgZmlsZVxyXG4gICAgaWYgKGZpbGUuc2l6ZSA9PT0gMCkge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignRmlsZSBpcyBlbXB0eScpO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChmaWxlLnNpemUgPiAxMCAqIDEwMjQgKiAxMDI0KSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGaWxlIHNpemUgbXVzdCBiZSBsZXNzIHRoYW4gMTBNQicpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIENvbnZlcnQgdG8gQnVmZmVyXHJcbiAgICBjb25zdCBidWZmZXIgPSBCdWZmZXIuZnJvbShhd2FpdCBmaWxlLmFycmF5QnVmZmVyKCkpO1xyXG4gICAgY29uc3QgcGF0aCA9IGAke3Nlc3Npb24udXNlci5pZH0vJHt0YXNrSWR9LyR7RGF0ZS5ub3coKX0tJHtmaWxlLm5hbWV9YDtcclxuXHJcbiAgICAvLyBVcGxvYWQgdG8gJ2V2aWRlbmNlJyBidWNrZXQgKHByaXZhdGUpXHJcbiAgICBjb25zdCB7IHBhdGg6IHN0b3JhZ2VQYXRoIH0gPSBhd2FpdCB1cGxvYWRGaWxlKCdldmlkZW5jZScsIHBhdGgsIGJ1ZmZlciwge1xyXG4gICAgICAgIGNvbnRlbnRUeXBlOiBmaWxlLnR5cGUsXHJcbiAgICAgICAgdXBzZXJ0OiB0cnVlXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBUcnkgdG8gZmluZCBleGlzdGluZyBjb2RlIHN1Ym1pc3Npb24gZmlyc3RcclxuICAgIC8vIFByaW9yaXR5IDE6IEZpbmQgYnkgbGl2ZVNlc3Npb25JZCBhbmQgcXVlc3Rpb25JZCAobW9zdCBzcGVjaWZpYylcclxuICAgIGxldCBjb2RlU3VibWlzc2lvbiA9IGxpdmVTZXNzaW9uSWQgPyBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi5maW5kRmlyc3Qoe1xyXG4gICAgICAgIHdoZXJlOiB7XHJcbiAgICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgICAgc3R1ZGVudElkOiBzZXNzaW9uLnVzZXIuaWQsXHJcbiAgICAgICAgICAgIGxpdmVTZXNzaW9uSWQsXHJcbiAgICAgICAgICAgIHF1ZXN0aW9uSWQ6IHsgbm90OiBudWxsIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIG9yZGVyQnk6IHsgY3JlYXRlZEF0OiAnZGVzYycgfVxyXG4gICAgfSkgOiBudWxsO1xyXG5cclxuICAgIC8vIFByaW9yaXR5IDI6IEZpbmQgYW55IHN1Ym1pc3Npb24gd2l0aCBxdWVzdGlvbklkIGZvciB0aGlzIHRhc2tcclxuICAgIGlmICghY29kZVN1Ym1pc3Npb24pIHtcclxuICAgICAgICBjb2RlU3VibWlzc2lvbiA9IGF3YWl0IHByaXNtYS5zdWJtaXNzaW9uLmZpbmRGaXJzdCh7XHJcbiAgICAgICAgICAgIHdoZXJlOiB7XHJcbiAgICAgICAgICAgICAgICB0YXNrSWQsXHJcbiAgICAgICAgICAgICAgICBzdHVkZW50SWQ6IHNlc3Npb24udXNlci5pZCxcclxuICAgICAgICAgICAgICAgIHF1ZXN0aW9uSWQ6IHsgbm90OiBudWxsIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgb3JkZXJCeTogeyBjcmVhdGVkQXQ6ICdkZXNjJyB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGNvZGVTdWJtaXNzaW9uKSB7XHJcbiAgICAgICAgLy8gQXR0YWNoIFBERiB0byBleGlzdGluZyBjb2RlIHN1Ym1pc3Npb25cclxuICAgICAgICBhd2FpdCBwcmlzbWEuc3VibWlzc2lvbi51cGRhdGUoe1xyXG4gICAgICAgICAgICB3aGVyZTogeyBpZDogY29kZVN1Ym1pc3Npb24uaWQgfSxcclxuICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgZXZpZGVuY2VQZGZQYXRoOiBzdG9yYWdlUGF0aCxcclxuICAgICAgICAgICAgICAgIGxpdmVTZXNzaW9uSWQ6IGxpdmVTZXNzaW9uSWQgfHwgY29kZVN1Ym1pc3Npb24ubGl2ZVNlc3Npb25JZCxcclxuICAgICAgICAgICAgICAgIHN0YXR1czogJ1NVQk1JVFRFRCcsXHJcbiAgICAgICAgICAgICAgICBzdWJtaXR0ZWRBdDogY29kZVN1Ym1pc3Npb24uc3VibWl0dGVkQXQgfHwgbmV3IERhdGUoKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIE5vIGNvZGUgc3VibWlzc2lvbiBmb3VuZCAtIHRoaXMgc2hvdWxkbid0IG5vcm1hbGx5IGhhcHBlbiBmb3IgSlVSTkFMIHRhc2tzXHJcbiAgICAgICAgLy8gQ3JlYXRlIG1pbmltYWwgc3VibWlzc2lvbiB3aXRoIGp1c3QgdGhlIFBERlxyXG4gICAgICAgIGF3YWl0IHByaXNtYS5zdWJtaXNzaW9uLmNyZWF0ZSh7XHJcbiAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIHRhc2tJZCxcclxuICAgICAgICAgICAgICAgIHN0dWRlbnRJZDogc2Vzc2lvbi51c2VyLmlkLFxyXG4gICAgICAgICAgICAgICAgbGl2ZVNlc3Npb25JZCxcclxuICAgICAgICAgICAgICAgIGV2aWRlbmNlUGRmUGF0aDogc3RvcmFnZVBhdGgsXHJcbiAgICAgICAgICAgICAgICBzdGF0dXM6ICdTVUJNSVRURUQnLFxyXG4gICAgICAgICAgICAgICAgc3VibWl0dGVkQXQ6IG5ldyBEYXRlKClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL2FzaXN0ZW4vZ3JhZGluZycpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiaVNBbU5zQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StudentLiveClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ui/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelCard$3e$__ = __turbopack_context__.i("[project]/components/ui/PixelCard.tsx [app-client] (ecmascript) <export default as PixelCard>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelButton$3e$__ = __turbopack_context__.i("[project]/components/ui/PixelButton.tsx [app-client] (ecmascript) <export default as PixelButton>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-client] (ecmascript) <export default as CheckCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/save.js [app-client] (ecmascript) <export default as Save>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$upload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/upload.js [app-client] (ecmascript) <export default as Upload>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hand$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Hand$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/hand.js [app-client] (ecmascript) <export default as Hand>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$presentation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Presentation$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/presentation.js [app-client] (ecmascript) <export default as Presentation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$3fa5ef__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:3fa5ef [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$a1d757__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:a1d757 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$fb02fe__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:fb02fe [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PresentationViewer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/PresentationViewer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
// Helper function to safely parse JSON-like option strings
function safeParseJSON(jsonInput) {
    if (!jsonInput) return [];
    if (Array.isArray(jsonInput)) {
        return jsonInput.map((item)=>typeof item === 'string' ? item : JSON.stringify(item)).filter(Boolean);
    }
    if (typeof jsonInput !== 'string') {
        return [];
    }
    const trimmed = jsonInput.trim();
    if (!trimmed) return [];
    const looksLikeJson = /^[\[\{"]/.test(trimmed);
    if (looksLikeJson) {
        try {
            const parsed = JSON.parse(trimmed);
            if (Array.isArray(parsed)) {
                return parsed.map((item)=>typeof item === 'string' ? item : JSON.stringify(item));
            }
            if (typeof parsed === 'string') {
                return [
                    parsed
                ];
            }
            if (parsed && typeof parsed === 'object') {
                return Object.values(parsed).map((item)=>typeof item === 'string' ? item : JSON.stringify(item));
            }
        } catch (error) {
            console.warn('Failed to parse options JSON:', error, 'Value:', jsonInput);
        }
    }
    return trimmed.split(/[\r\n,;]+/).map((item)=>item.trim()).filter(Boolean);
}
function StudentLiveClient({ session, liveSessionId, userId }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [currentStage, setCurrentStage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(session.stages.length > 0 ? session.stages[session.stages.length - 1].type : null);
    const [stageIndex, setStageIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(session.currentStageIndex || 0);
    const [stageData, setStageData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(session.stages.length > 0 ? session.stages[session.stages.length - 1] : null);
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(session.status);
    // Submission State
    const [mcqAnswers, setMcqAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [codeAnswer, setCodeAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isSubmitting, setIsSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [lastAutosave, setLastAutosave] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Evidence Upload State
    const [showUploadModal, setShowUploadModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isUploading, setIsUploading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Quiz Result State
    const [showQuizResult, setShowQuizResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [quizResult, setQuizResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [hasSubmitted, setHasSubmitted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Submission Success Modal State
    const [showSubmissionSuccess, setShowSubmissionSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [submissionType, setSubmissionType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Feedback State
    const [feedbackRating, setFeedbackRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [feedbackComment, setFeedbackComment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [showFeedbackThankYou, setShowFeedbackThankYou] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Attendance State
    const [attendanceMarked, setAttendanceMarked] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StudentLiveClient.useEffect": ()=>{
            // Don't subscribe if session is already completed
            if (status === 'COMPLETED') return;
            const channel = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].channel(`live-${liveSessionId}`).on('broadcast', {
                event: 'stage_change'
            }, {
                "StudentLiveClient.useEffect.channel": (payload)=>{
                    console.log('[StudentLiveClient] Stage change broadcast received:', payload);
                    const newStage = payload.payload.stage;
                    const newIndex = payload.payload.index;
                    console.log('[StudentLiveClient] Updating to stage:', newStage, 'index:', newIndex);
                    // Update all stage-related state
                    setCurrentStage(newStage);
                    setStageIndex(newIndex);
                    setStageData({
                        type: newStage,
                        startedAt: payload.payload.startedAt,
                        durationSec: payload.payload.duration
                    });
                    // Reset all submission-related state
                    setMcqAnswers({});
                    setCodeAnswer('');
                    setLastAutosave(null);
                    setShowQuizResult(false);
                    setQuizResult(null);
                    setHasSubmitted(false);
                    setShowSubmissionSuccess(false);
                    setSubmissionType(null);
                    setShowUploadModal(false);
                    console.log('[StudentLiveClient] Stage state updated successfully');
                }
            }["StudentLiveClient.useEffect.channel"]).on('broadcast', {
                event: 'session_start'
            }, {
                "StudentLiveClient.useEffect.channel": (payload)=>{
                    console.log('[StudentLiveClient] Session started');
                    setStatus('ACTIVE');
                }
            }["StudentLiveClient.useEffect.channel"]).on('broadcast', {
                event: 'session_end'
            }, {
                "StudentLiveClient.useEffect.channel": (payload)=>{
                    console.log('[StudentLiveClient] Session ended');
                    setStatus('COMPLETED');
                }
            }["StudentLiveClient.useEffect.channel"]).on('postgres_changes', {
                event: 'INSERT',
                schema: 'public',
                table: 'Attendance',
                filter: `studentId=eq.${userId}`
            }, {
                "StudentLiveClient.useEffect.channel": (payload)=>{
                    console.log('Attendance marked:', payload);
                    setAttendanceMarked(true);
                }
            }["StudentLiveClient.useEffect.channel"]).subscribe();
            return ({
                "StudentLiveClient.useEffect": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].removeChannel(channel);
                }
            })["StudentLiveClient.useEffect"];
        }
    }["StudentLiveClient.useEffect"], [
        liveSessionId,
        userId,
        status
    ]);
    // Autosave for Code
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StudentLiveClient.useEffect": ()=>{
            if (currentStage !== 'JURNAL' || !codeAnswer) return;
            const timeout = setTimeout({
                "StudentLiveClient.useEffect.timeout": async ()=>{
                    try {
                        const task = session.moduleWeek.tasks.find({
                            "StudentLiveClient.useEffect.timeout.task": (t)=>t.type.toUpperCase() === 'JURNAL'
                        }["StudentLiveClient.useEffect.timeout.task"]);
                        const question = task?.questions[0];
                        if (task && question) {
                            await fetch('/api/autosave', {
                                method: 'POST',
                                body: JSON.stringify({
                                    taskId: task.id,
                                    questionId: question.id,
                                    code: codeAnswer,
                                    liveSessionId
                                })
                            });
                            setLastAutosave(new Date());
                        }
                    } catch (e) {
                        console.error("Autosave failed", e);
                    }
                }
            }["StudentLiveClient.useEffect.timeout"], 2000);
            return ({
                "StudentLiveClient.useEffect": ()=>clearTimeout(timeout)
            })["StudentLiveClient.useEffect"];
        }
    }["StudentLiveClient.useEffect"], [
        codeAnswer,
        currentStage,
        session.moduleWeek.tasks,
        liveSessionId
    ]);
    const handleMCQSubmit = async (taskId, taskType)=>{
        if (!confirm('Submit answers? You cannot change them after submitting.')) return;
        setIsSubmitting(true);
        try {
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$3fa5ef__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["submitMCQ"])(taskId, mcqAnswers, liveSessionId);
            // Lock submission
            setHasSubmitted(true);
            // Show result modal first
            setQuizResult({
                score: result.score || 0,
                total: result.total || 0
            });
            setShowQuizResult(true);
            // After 3 seconds, close quiz result and show submission success
            setTimeout(()=>{
                setShowQuizResult(false);
                setSubmissionType(taskType);
                setShowSubmissionSuccess(true);
            }, 3000);
        } catch (e) {
            alert('Failed to submit: ' + e.message);
            setHasSubmitted(false);
        } finally{
            setIsSubmitting(false);
        }
    };
    const handleCodeSubmit = async (taskId, questionId)=>{
        if (!confirm('Submit code? Ensure you have tested it.')) return;
        setIsSubmitting(true);
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$a1d757__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["submitCode"])(taskId, questionId, codeAnswer, liveSessionId);
            // Lock submission
            setHasSubmitted(true);
            // Show submission success modal
            setSubmissionType('JURNAL');
            setShowSubmissionSuccess(true);
        } catch (e) {
            alert('Failed to submit: ' + e.message);
            setHasSubmitted(false);
        } finally{
            setIsSubmitting(false);
        }
    };
    const handleUploadEvidence = async (formData)=>{
        setIsUploading(true);
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$fb02fe__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["uploadEvidence"])(formData);
            alert('Evidence uploaded successfully!');
            setShowUploadModal(false);
        } catch (e) {
            alert('Failed to upload evidence: ' + e.message);
        } finally{
            setIsUploading(false);
        }
    };
    const handleFeedbackSubmit = async ()=>{
        if (feedbackRating === 0) {
            alert('Please select a rating');
            return;
        }
        try {
            const response = await fetch('/api/feedback', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    liveSessionId,
                    rating: feedbackRating,
                    comment: feedbackComment,
                    type: 'PRAKTIKUM'
                })
            });
            if (!response.ok) throw new Error('Failed to submit feedback');
            // Lock feedback form permanently
            setShowFeedbackThankYou(true);
        } catch (e) {
            alert('Failed to submit feedback: ' + e.message);
        }
    };
    if (status === 'COMPLETED') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelCard$3e$__["PixelCard"], {
            className: "text-center py-20",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-3xl font-pixel text-emerald-400 mb-4",
                    children: "SESSION COMPLETED"
                }, void 0, false, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 274,
                    columnNumber: 13
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Thank you for attending today's practical session."
                }, void 0, false, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 275,
                    columnNumber: 13
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelButton$3e$__["PixelButton"], {
                    onClick: ()=>router.push('/dashboard/praktikan'),
                    variant: "primary",
                    className: "mt-8 inline-block",
                    children: "Back to Dashboard"
                }, void 0, false, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 276,
                    columnNumber: 13
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
            lineNumber: 273,
            columnNumber: 9
        }, this);
    }
    if (!currentStage || currentStage === 'OPENING') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-center justify-center min-h-[60vh] space-y-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "animate-pulse",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-4xl font-pixel text-white text-center mb-4",
                            children: "WAITING FOR SESSION TO START"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 291,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-slate-400 text-center",
                            children: "Please wait for the assistant/publication to start the session."
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 292,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 290,
                    columnNumber: 13
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-16 h-16 border-4 border-t-emerald-400 border-slate-700 rounded-full animate-spin"
                }, void 0, false, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 294,
                    columnNumber: 13
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
            lineNumber: 289,
            columnNumber: 9
        }, this);
    }
    // Helper to find tasks
    const pretestTask = session.moduleWeek.tasks.find((t)=>t.type.toUpperCase() === 'PRETEST');
    const jurnalTask = session.moduleWeek.tasks.find((t)=>t.type.toUpperCase() === 'JURNAL');
    const posttestTask = session.moduleWeek.tasks.find((t)=>t.type.toUpperCase() === 'POSTTEST');
    // Timer Logic
    const endTime = stageData?.startedAt ? new Date(new Date(stageData.startedAt).getTime() + stageData.durationSec * 1000) : null;
    const isTimedStage = [
        'PRETEST',
        'JURNAL',
        'POSTTEST'
    ].includes(currentStage);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            isTimedStage && endTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "sticky top-20 z-40 bg-slate-900/90 backdrop-blur border-b-4 border-rose-500 p-4 flex justify-between items-center mb-8 pixel-shadow",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                className: "text-rose-500 animate-pulse"
                            }, void 0, false, {
                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                lineNumber: 317,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-bold text-rose-500",
                                children: "TIME REMAINING"
                            }, void 0, false, {
                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                lineNumber: 318,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                        lineNumber: 316,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "font-pixel text-2xl text-white",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Countdown, {
                            target: endTime
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 321,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                        lineNumber: 320,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                lineNumber: 315,
                columnNumber: 14
            }, this),
            currentStage === 'ABSEN' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center justify-center min-h-[60vh] space-y-8",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `text-center transition-all duration-500 ${attendanceMarked ? 'scale-110' : ''}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-8",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hand$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Hand$3e$__["Hand"], {
                                size: 80,
                                className: `mx-auto ${attendanceMarked ? 'text-emerald-400' : 'text-amber-400 animate-bounce'}`
                            }, void 0, false, {
                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                lineNumber: 331,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 330,
                            columnNumber: 21
                        }, this),
                        !attendanceMarked ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-4xl font-pixel text-white mb-4",
                                    children: "ATTENDANCE CHECK"
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 335,
                                    columnNumber: 29
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xl text-amber-400 mb-2",
                                    children: "Ketika Nama dipanggil,"
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 336,
                                    columnNumber: 29
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-2xl font-bold text-amber-300",
                                    children: "tolong angkat tangan! 🙋‍♂️"
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 337,
                                    columnNumber: 29
                                }, this)
                            ]
                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-4xl font-pixel text-emerald-400 mb-4",
                                    children: "ATTENDANCE MARKED ✓"
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 341,
                                    columnNumber: 29
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xl text-emerald-300",
                                    children: "Your attendance has been recorded"
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 342,
                                    columnNumber: 29
                                }, this)
                            ]
                        }, void 0, true)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 329,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                lineNumber: 328,
                columnNumber: 13
            }, this),
            showQuizResult && quizResult && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-slate-900 border-4 border-emerald-500 w-full max-w-lg p-8 relative text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                            size: 64,
                            className: "mx-auto text-emerald-400 mb-4"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 353,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-3xl font-pixel text-emerald-400 mb-4",
                            children: "SELAMAT!"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 354,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xl text-white mb-6",
                            children: "Telah berhasil menyelesaikan quiz"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 355,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-slate-800 border-2 border-slate-700 p-6 mb-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-4xl font-pixel text-white mb-2",
                                    children: [
                                        quizResult.score,
                                        " / ",
                                        quizResult.total
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 358,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-slate-400",
                                    children: "Your Score"
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 361,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 357,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-slate-500 animate-pulse",
                            children: "Loading..."
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 364,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 352,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                lineNumber: 351,
                columnNumber: 13
            }, this),
            showSubmissionSuccess && submissionType && endTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-slate-900 border-4 border-emerald-500 w-full max-w-lg p-8 relative text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                            size: 64,
                            className: "mx-auto text-emerald-400 mb-4"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 373,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-3xl font-pixel text-emerald-400 mb-4",
                            children: "SELAMAT!"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 374,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xl text-white mb-6",
                            children: [
                                "Anda telah menyelesaikan ",
                                submissionType === 'PRETEST' ? 'Pre-Test' : submissionType === 'POSTTEST' ? 'Post-Test' : 'Jurnal'
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 375,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-slate-800 border-2 border-slate-700 p-6 mb-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-sm text-slate-400 mb-2",
                                    children: "Sisa Waktu Sesi:"
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 380,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-5xl font-pixel text-emerald-400",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Countdown, {
                                        target: endTime
                                    }, void 0, false, {
                                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                        lineNumber: 382,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 381,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 379,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-lg text-white mb-2",
                            children: "Silahkan tunggu waktu sesi hingga selesai"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 386,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-slate-500",
                            children: "Mohon tunggu asisten untuk melanjutkan ke stage berikutnya"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 387,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 372,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                lineNumber: 371,
                columnNumber: 13
            }, this),
            currentStage === 'TP_REVIEW' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-amber-900/50 border-2 border-amber-500 p-6 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$presentation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Presentation$3e$__["Presentation"], {
                                size: 48,
                                className: "mx-auto text-amber-400 mb-4"
                            }, void 0, false, {
                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                lineNumber: 396,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-3xl font-pixel text-white mb-2",
                                children: "PEMBAHASAN MATERI"
                            }, void 0, false, {
                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                lineNumber: 397,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-amber-300",
                                children: "Perhatikan materi yang disampaikan oleh Asisten Praktikum"
                            }, void 0, false, {
                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                lineNumber: 398,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                        lineNumber: 395,
                        columnNumber: 17
                    }, this),
                    session.tpReviewPresentationPath ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelCard$3e$__["PixelCard"], {
                        title: "TP PRESENTATION",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PresentationViewer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            liveSessionId: liveSessionId,
                            presentationUrl: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileUrl"])('materials', session.tpReviewPresentationPath),
                            initialSlide: session.tpReviewCurrentSlide || 1,
                            presentationType: "TP"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 403,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                        lineNumber: 402,
                        columnNumber: 21
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center py-12 text-slate-500",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "Menunggu asisten memulai presentasi..."
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 412,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                        lineNumber: 411,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                lineNumber: 394,
                columnNumber: 13
            }, this),
            currentStage === 'JURNAL_REVIEW' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-indigo-900/50 border-2 border-indigo-500 p-6 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$presentation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Presentation$3e$__["Presentation"], {
                                size: 48,
                                className: "mx-auto text-indigo-400 mb-4"
                            }, void 0, false, {
                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                lineNumber: 422,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-3xl font-pixel text-white mb-2",
                                children: "REVIEW JURNAL"
                            }, void 0, false, {
                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                lineNumber: 423,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-indigo-300",
                                children: "Perhatikan pembahasan yang disampaikan oleh Asisten Praktikum"
                            }, void 0, false, {
                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                lineNumber: 424,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                        lineNumber: 421,
                        columnNumber: 17
                    }, this),
                    session.jurnalReviewPresentationPath ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelCard$3e$__["PixelCard"], {
                        title: "JURNAL PRESENTATION",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PresentationViewer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            liveSessionId: liveSessionId,
                            presentationUrl: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileUrl"])('materials', session.jurnalReviewPresentationPath),
                            initialSlide: session.jurnalReviewCurrentSlide || 1,
                            presentationType: "JURNAL"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 429,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                        lineNumber: 428,
                        columnNumber: 21
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center py-12 text-slate-500",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "Menunggu asisten memulai presentasi..."
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 438,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                        lineNumber: 437,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                lineNumber: 420,
                columnNumber: 13
            }, this),
            currentStage === 'PRETEST' && pretestTask && !hasSubmitted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelCard$3e$__["PixelCard"], {
                    title: `PRE-TEST: ${pretestTask.title}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mb-4 text-slate-300",
                            dangerouslySetInnerHTML: {
                                __html: pretestTask.instructions
                            }
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 447,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-6",
                            children: [
                                pretestTask.questions.map((q, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-4 border-2 border-slate-700 bg-slate-800",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-bold mb-4",
                                                children: [
                                                    idx + 1,
                                                    ". ",
                                                    q.prompt
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                lineNumber: 452,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-2",
                                                children: safeParseJSON(q.optionsJson).map((opt, optIdx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        onClick: ()=>setMcqAnswers((prev)=>({
                                                                    ...prev,
                                                                    [q.id]: optIdx.toString()
                                                                })),
                                                        className: `p-3 border cursor-pointer transition-colors ${mcqAnswers[q.id] === optIdx.toString() ? 'bg-indigo-600 border-indigo-400 text-white' : 'border-slate-600 hover:bg-slate-700 text-slate-300'}`,
                                                        children: opt
                                                    }, optIdx, false, {
                                                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                        lineNumber: 455,
                                                        columnNumber: 41
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                lineNumber: 453,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, q.id, true, {
                                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                        lineNumber: 451,
                                        columnNumber: 29
                                    }, this)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelButton$3e$__["PixelButton"], {
                                    variant: "primary",
                                    className: "w-full",
                                    onClick: ()=>handleMCQSubmit(pretestTask.id, 'PRETEST'),
                                    disabled: isSubmitting,
                                    children: isSubmitting ? 'SUBMITTING...' : 'SUBMIT PRE-TEST'
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 470,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 449,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 446,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                lineNumber: 445,
                columnNumber: 14
            }, this),
            currentStage === 'JURNAL' && jurnalTask && !hasSubmitted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "lg:col-span-2 space-y-6",
                        children: jurnalTask.questions.map((q, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelCard$3e$__["PixelCard"], {
                                title: `TASK ${idx + 1}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "prose prose-invert max-w-none mb-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-bold text-emerald-400",
                                                children: q.prompt
                                            }, void 0, false, {
                                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                lineNumber: 489,
                                                columnNumber: 33
                                            }, this),
                                            q.constraints && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                                                className: "text-xs text-slate-500 mt-2",
                                                children: q.constraints
                                            }, void 0, false, {
                                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                lineNumber: 490,
                                                columnNumber: 51
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                        lineNumber: 488,
                                        columnNumber: 30
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between items-center mb-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: "text-xs font-bold uppercase text-slate-400",
                                                        children: "Your Code"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                        lineNumber: 495,
                                                        columnNumber: 37
                                                    }, this),
                                                    lastAutosave && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs text-emerald-500 flex items-center gap-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__["Save"], {
                                                                size: 12
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                                lineNumber: 498,
                                                                columnNumber: 45
                                                            }, this),
                                                            " Autosaved ",
                                                            lastAutosave.toLocaleTimeString()
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                        lineNumber: 497,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                lineNumber: 494,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                className: "w-full h-96 bg-slate-950 border-2 border-slate-700 p-4 font-mono text-sm text-emerald-400 focus:border-emerald-500 outline-none",
                                                placeholder: "// Type your code here...",
                                                value: codeAnswer,
                                                onChange: (e)=>setCodeAnswer(e.target.value)
                                            }, void 0, false, {
                                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                lineNumber: 502,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-4",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelButton$3e$__["PixelButton"], {
                                                    variant: "success",
                                                    className: "w-full",
                                                    onClick: ()=>handleCodeSubmit(jurnalTask.id, q.id),
                                                    disabled: isSubmitting,
                                                    children: "SUBMIT CODE ANSWER"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                    lineNumber: 509,
                                                    columnNumber: 37
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                lineNumber: 508,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                        lineNumber: 493,
                                        columnNumber: 30
                                    }, this)
                                ]
                            }, q.id, true, {
                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                lineNumber: 487,
                                columnNumber: 25
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                        lineNumber: 485,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelCard$3e$__["PixelCard"], {
                            title: "INSTRUCTIONS",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "prose prose-invert text-sm",
                                    dangerouslySetInnerHTML: {
                                        __html: jurnalTask.instructions
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 524,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-4 p-4 bg-slate-800 border border-slate-600",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-slate-400 mb-2",
                                            children: "Don't forget to upload evidence PDF."
                                        }, void 0, false, {
                                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                            lineNumber: 526,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelButton$3e$__["PixelButton"], {
                                            variant: "outline",
                                            className: "w-full text-xs",
                                            onClick: ()=>setShowUploadModal(true),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$upload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"], {
                                                    size: 14,
                                                    className: "mr-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                    lineNumber: 532,
                                                    columnNumber: 33
                                                }, this),
                                                "UPLOAD EVIDENCE"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                            lineNumber: 527,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 525,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 523,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                        lineNumber: 522,
                        columnNumber: 17
                    }, this),
                    showUploadModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-slate-900 border-2 border-slate-600 w-full max-w-md p-6 relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setShowUploadModal(false),
                                    className: "absolute top-2 right-2 text-slate-400 hover:text-white",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                        size: 20
                                    }, void 0, false, {
                                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                        lineNumber: 547,
                                        columnNumber: 33
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 543,
                                    columnNumber: 29
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-xl font-pixel text-white mb-4",
                                    children: "UPLOAD EVIDENCE"
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 549,
                                    columnNumber: 29
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                    action: handleUploadEvidence,
                                    className: "space-y-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "hidden",
                                            name: "taskId",
                                            value: jurnalTask.id
                                        }, void 0, false, {
                                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                            lineNumber: 551,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "hidden",
                                            name: "liveSessionId",
                                            value: liveSessionId
                                        }, void 0, false, {
                                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                            lineNumber: 552,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-xs text-slate-400 mb-2 uppercase",
                                                    children: "Select PDF File"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                    lineNumber: 555,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "file",
                                                    name: "file",
                                                    accept: ".pdf",
                                                    className: "w-full bg-black border border-slate-700 p-2 text-sm",
                                                    required: true
                                                }, void 0, false, {
                                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                    lineNumber: 556,
                                                    columnNumber: 37
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                            lineNumber: 554,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "pt-4",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelButton$3e$__["PixelButton"], {
                                                type: "submit",
                                                variant: "primary",
                                                className: "w-full",
                                                disabled: isUploading,
                                                children: isUploading ? 'UPLOADING...' : 'UPLOAD PDF'
                                            }, void 0, false, {
                                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                lineNumber: 566,
                                                columnNumber: 37
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                            lineNumber: 565,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 550,
                                    columnNumber: 29
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 542,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                        lineNumber: 541,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                lineNumber: 484,
                columnNumber: 14
            }, this),
            currentStage === 'POSTTEST' && posttestTask && !hasSubmitted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelCard$3e$__["PixelCard"], {
                    title: `POST-TEST: ${posttestTask.title}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mb-4 text-slate-300",
                            dangerouslySetInnerHTML: {
                                __html: posttestTask.instructions
                            }
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 585,
                            columnNumber: 22
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-6",
                            children: [
                                posttestTask.questions.map((q, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-4 border-2 border-slate-700 bg-slate-800",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-bold mb-4",
                                                children: [
                                                    idx + 1,
                                                    ". ",
                                                    q.prompt
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                lineNumber: 589,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-2",
                                                children: safeParseJSON(q.optionsJson).map((opt, optIdx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        onClick: ()=>setMcqAnswers((prev)=>({
                                                                    ...prev,
                                                                    [q.id]: optIdx.toString()
                                                                })),
                                                        className: `p-3 border cursor-pointer transition-colors ${mcqAnswers[q.id] === optIdx.toString() ? 'bg-indigo-600 border-indigo-400 text-white' : 'border-slate-600 hover:bg-slate-700 text-slate-300'}`,
                                                        children: opt
                                                    }, optIdx, false, {
                                                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                        lineNumber: 592,
                                                        columnNumber: 41
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                                lineNumber: 590,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, q.id, true, {
                                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                        lineNumber: 588,
                                        columnNumber: 29
                                    }, this)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelButton$3e$__["PixelButton"], {
                                    variant: "primary",
                                    className: "w-full",
                                    onClick: ()=>handleMCQSubmit(posttestTask.id, 'POSTTEST'),
                                    disabled: isSubmitting,
                                    children: isSubmitting ? 'SUBMITTING...' : 'SUBMIT POST-TEST'
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 607,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 586,
                            columnNumber: 22
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 584,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                lineNumber: 583,
                columnNumber: 13
            }, this),
            currentStage === 'FEEDBACK' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelCard$3e$__["PixelCard"], {
                title: "FEEDBACK",
                className: "max-w-2xl mx-auto",
                children: !showFeedbackThankYou ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center space-y-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-xl font-bold text-white",
                            children: "Rate this Session"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 624,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-center gap-2",
                            children: [
                                1,
                                2,
                                3,
                                4,
                                5
                            ].map((star)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setFeedbackRating(star),
                                    className: `text-4xl transition-all hover:scale-125 ${feedbackRating >= star ? 'opacity-100' : 'opacity-30'}`,
                                    children: "⭐"
                                }, star, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 627,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 625,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            className: "w-full bg-slate-800 border border-slate-600 p-3 text-white min-h-[120px]",
                            placeholder: "Any comments or suggestions?",
                            value: feedbackComment,
                            onChange: (e)=>setFeedbackComment(e.target.value)
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 636,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PixelButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PixelButton$3e$__["PixelButton"], {
                            variant: "primary",
                            onClick: handleFeedbackSubmit,
                            children: "SEND FEEDBACK"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 642,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 623,
                    columnNumber: 21
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center py-12 space-y-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                            size: 64,
                            className: "mx-auto text-emerald-400"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 648,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-2xl font-pixel text-emerald-400",
                            children: "TERIMA KASIH!"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 649,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-lg text-slate-300 mb-4",
                            children: "Telah mengisi feedback"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 650,
                            columnNumber: 25
                        }, this),
                        endTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-slate-800 border-2 border-slate-700 p-6 mt-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-sm text-slate-400 mb-2",
                                    children: "Sisa Waktu Sesi:"
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 654,
                                    columnNumber: 33
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-5xl font-pixel text-emerald-400",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Countdown, {
                                        target: endTime
                                    }, void 0, false, {
                                        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                        lineNumber: 656,
                                        columnNumber: 37
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                                    lineNumber: 655,
                                    columnNumber: 33
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 653,
                            columnNumber: 29
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-lg text-white mt-6",
                            children: "Silahkan tunggu hingga waktu sesi habis"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 661,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-slate-500",
                            children: "Mohon tunggu hingga sesi selesai"
                        }, void 0, false, {
                            fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                            lineNumber: 662,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                    lineNumber: 647,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
                lineNumber: 621,
                columnNumber: 13
            }, this)
        ]
    }, `stage-${currentStage}-${stageIndex}`, true, {
        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
        lineNumber: 312,
        columnNumber: 5
    }, this);
}
_s(StudentLiveClient, "SOitXGLpHscuhCMWmfIGCQUH/Ak=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = StudentLiveClient;
function Countdown({ target }) {
    _s1();
    const [left, setLeft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Countdown.useEffect": ()=>{
            const interval = setInterval({
                "Countdown.useEffect.interval": ()=>{
                    const now = new Date();
                    const diff = Math.max(0, Math.floor((target.getTime() - now.getTime()) / 1000));
                    setLeft(diff);
                }
            }["Countdown.useEffect.interval"], 1000);
            return ({
                "Countdown.useEffect": ()=>clearInterval(interval)
            })["Countdown.useEffect"];
        }
    }["Countdown.useEffect"], [
        target
    ]);
    const m = Math.floor(left / 60);
    const s = left % 60;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        children: [
            m.toString().padStart(2, '0'),
            ":",
            s.toString().padStart(2, '0')
        ]
    }, void 0, true, {
        fileName: "[project]/app/live/[liveSessionId]/_components/StudentLiveClient.tsx",
        lineNumber: 685,
        columnNumber: 12
    }, this);
}
_s1(Countdown, "3UI8QGtGulNugC/Gs2MYSDm3U28=");
_c1 = Countdown;
var _c, _c1;
__turbopack_context__.k.register(_c, "StudentLiveClient");
__turbopack_context__.k.register(_c1, "Countdown");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_4c3e8baf._.js.map