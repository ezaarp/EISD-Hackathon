(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_8102f513._.js",
  "static/chunks/node_modules_08ae9508._.js"
],
    source: "dynamic"
});
