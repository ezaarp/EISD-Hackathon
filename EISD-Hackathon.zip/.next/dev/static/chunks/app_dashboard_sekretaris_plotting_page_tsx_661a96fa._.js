(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_15a2839e._.js",
  "static/chunks/node_modules_0ede4f41._.js"
],
    source: "dynamic"
});
