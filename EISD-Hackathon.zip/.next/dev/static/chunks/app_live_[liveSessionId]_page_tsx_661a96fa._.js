(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_4c3e8baf._.js",
  "static/chunks/node_modules_7ddb637f._.js"
],
    source: "dynamic"
});
