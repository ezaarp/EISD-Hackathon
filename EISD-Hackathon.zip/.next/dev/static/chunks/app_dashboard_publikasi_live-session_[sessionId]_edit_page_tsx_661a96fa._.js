(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_ed0847d3._.js",
  "static/chunks/node_modules_3498644d._.js"
],
    source: "dynamic"
});
