(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_actions_publikasi_ts_147b50dd._.js",
  "static/chunks/_a1464f44._.js",
  "static/chunks/node_modules_d8d82259._.js"
],
    source: "dynamic"
});
