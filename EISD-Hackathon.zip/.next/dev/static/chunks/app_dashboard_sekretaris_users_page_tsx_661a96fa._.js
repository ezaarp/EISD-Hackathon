(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_1248372d._.js",
  "static/chunks/node_modules_2cd2e795._.js"
],
    source: "dynamic"
});
