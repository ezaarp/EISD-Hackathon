(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_459ba4bd._.js",
  "static/chunks/node_modules_a67da27a._.js"
],
    source: "dynamic"
});
