module.exports = [
"[project]/.next-internal/server/app/api/files/[bucket]/[...path]/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_files_%5Bbucket%5D_%5B___path%5D_route_actions_265cbd28.js.map