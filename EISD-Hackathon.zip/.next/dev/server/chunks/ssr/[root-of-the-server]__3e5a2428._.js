module.exports = [
"[externals]/@prisma/client [external] (@prisma/client, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client", () => require("@prisma/client"));

module.exports = mod;
}),
"[project]/lib/prisma.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "prisma",
    ()=>prisma
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs)");
;
const globalForPrisma = globalThis;
// Use a dummy URL during build if DATABASE_URL is not set
const databaseUrl = process.env.DATABASE_URL || 'postgresql://dummy:dummy@localhost:5432/dummy';
const prisma = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["PrismaClient"]({
    log: ("TURBOPACK compile-time truthy", 1) ? [
        'error',
        'warn'
    ] : "TURBOPACK unreachable",
    datasources: {
        db: {
            url: databaseUrl
        }
    }
});
if ("TURBOPACK compile-time truthy", 1) {
    globalForPrisma.prisma = prisma;
}
const __TURBOPACK__default__export__ = prisma;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/querystring [external] (querystring, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("querystring", () => require("querystring"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/lib/auth.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authOptions",
    ()=>authOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/providers/credentials.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$auth$2f$prisma$2d$adapter$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@auth/prisma-adapter/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bcryptjs/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs)");
;
;
;
;
;
const authOptions = {
    adapter: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$auth$2f$prisma$2d$adapter$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PrismaAdapter"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]),
    providers: [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])({
            name: 'Credentials',
            credentials: {
                username: {
                    label: 'Username',
                    type: 'text',
                    placeholder: 'NIM atau Kode Asprak'
                },
                password: {
                    label: 'Password',
                    type: 'password'
                },
                roleGate: {
                    label: 'Role Gate',
                    type: 'text'
                }
            },
            async authorize (credentials) {
                if (!credentials?.username || !credentials?.password) {
                    throw new Error('Username dan password harus diisi');
                }
                // Find user
                const user = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].user.findUnique({
                    where: {
                        username: credentials.username
                    }
                });
                if (!user || !user.isActive) {
                    throw new Error('Username atau password salah');
                }
                // Verify password
                const isPasswordValid = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].compare(credentials.password, user.passwordHash);
                if (!isPasswordValid) {
                    throw new Error('Username atau password salah');
                }
                // Enforce button-role mapping when provided
                if (credentials.roleGate) {
                    const gate = credentials.roleGate;
                    const role = user.role;
                    const allowedRoles = {
                        praktikan: [
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].PRAKTIKAN
                        ],
                        asisten: [
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].ASISTEN,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].MEDIA,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].KOORDINATOR,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].SEKRETARIS,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].PUBLIKASI,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].KOMDIS
                        ],
                        dosen: [
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].DOSEN,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].LABORAN
                        ]
                    };
                    const allowed = allowedRoles[gate];
                    if (allowed && !allowed.includes(role)) {
                        throw new Error('Silakan login melalui tombol yang sesuai dengan peran Anda');
                    }
                }
                return {
                    id: user.id,
                    username: user.username,
                    name: user.name,
                    email: user.email,
                    role: user.role
                };
            }
        })
    ],
    session: {
        strategy: 'jwt',
        maxAge: 30 * 24 * 60 * 60
    },
    pages: {
        signIn: '/login',
        error: '/login'
    },
    callbacks: {
        async jwt ({ token, user }) {
            if (user) {
                token.id = user.id;
                token.username = user.username;
                token.role = user.role;
            }
            return token;
        },
        async session ({ session, token }) {
            if (session.user) {
                session.user.id = token.id;
                session.user.username = token.username;
                session.user.role = token.role;
            }
            return session;
        }
    },
    secret: process.env.NEXTAUTH_SECRET,
    debug: ("TURBOPACK compile-time value", "development") === 'development'
};
}),
"[project]/lib/supabase.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "deleteFile",
    ()=>deleteFile,
    "getFileUrl",
    ()=>getFileUrl,
    "supabase",
    ()=>supabase,
    "supabaseAdmin",
    ()=>supabaseAdmin,
    "uploadFile",
    ()=>uploadFile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-rsc] (ecmascript) <locals>");
;
const supabaseUrl = ("TURBOPACK compile-time value", "https://oyfigjfooeoabvkavubu.supabase.co");
const supabaseAnonKey = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im95ZmlnamZvb2VvYWJ2a2F2dWJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQzMjU0MDMsImV4cCI6MjA3OTkwMTQwM30.VO4fK5BbLQh0BqhN8K4GW4Cg-wWLhsvlwWpVQpSjBvU");
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseAnonKey);
// Server-side Supabase client with service role (for admin operations)
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabaseAdmin = supabaseServiceKey ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseServiceKey) : null;
async function uploadFile(bucket, path, file, options) {
    const client = supabaseAdmin || supabase;
    const { data, error } = await client.storage.from(bucket).upload(path, file, {
        contentType: options?.contentType,
        cacheControl: options?.cacheControl || '3600',
        upsert: options?.upsert || false
    });
    if (error) {
        throw error;
    }
    // Get public URL
    const { data: urlData } = client.storage.from(bucket).getPublicUrl(path);
    return {
        path: data.path,
        publicUrl: urlData.publicUrl
    };
}
async function deleteFile(bucket, path) {
    const client = supabaseAdmin || supabase;
    const { error } = await client.storage.from(bucket).remove([
        path
    ]);
    if (error) {
        throw error;
    }
    return true;
}
function getFileUrl(bucket, path) {
    // Private buckets (evidence, violations, permissions) need signed URLs
    const privateBuckets = [
        'evidence',
        'violations',
        'permissions'
    ];
    if (privateBuckets.includes(bucket)) {
        // For private buckets, we need to generate signed URLs on the server
        // This function will return a path that will be handled by an API route
        return `/api/files/${bucket}/${encodeURIComponent(path)}`;
    }
    // For public buckets, use public URL
    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    return data.publicUrl;
}
const __TURBOPACK__default__export__ = supabase;
}),
"[project]/app/actions/publikasi.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4005a3c2b8d22ac85a53cd5c2e0dc8f2131c07c9d3":"updateQuestion","4029f378fc0ab886944db13c9633da4035b2a94fd5":"deleteTask","4034ceb19e11d9c2d9b52db62823108ab9e192811a":"updateTask","40aa9947d1dba9fe21117b5a3eab47f2d01f8afb57":"uploadMaterial","40ac5be5e44865bada321dfecbc470b89b110f458f":"createModuleWeek","40ced35877719c41ca82ada3a77ebb30f8fb2b23f3":"deleteContent","40e46a0c097fc450db95c0db91dee982239fa26e95":"startTP","40e906fc0cd018a0a3b6da8de345af3494607cdf30":"createTask","600f03de529dce81bfbf666534ae80d2c21ae11803":"createContent","60b8a894f2e3f2ebefd1f591d653d0d30eda11320b":"createQuestion","60d4df440faf09b82389496ce414cabb14e1d7414f":"uploadTaskFile"},"",""] */ __turbopack_context__.s([
    "createContent",
    ()=>createContent,
    "createModuleWeek",
    ()=>createModuleWeek,
    "createQuestion",
    ()=>createQuestion,
    "createTask",
    ()=>createTask,
    "deleteContent",
    ()=>deleteContent,
    "deleteTask",
    ()=>deleteTask,
    "startTP",
    ()=>startTP,
    "updateQuestion",
    ()=>updateQuestion,
    "updateTask",
    ()=>updateTask,
    "uploadMaterial",
    ()=>uploadMaterial,
    "uploadTaskFile",
    ()=>uploadTaskFile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/auth.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/cache.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
;
;
async function createContent(moduleWeekId, data) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || session.user.role !== 'PUBLIKASI') throw new Error('Unauthorized');
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].content.create({
        data: {
            moduleWeekId,
            title: data.title,
            type: data.type,
            storagePath: data.storagePath,
            visibility: 'PUBLIC'
        }
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/dashboard/publikasi/modules/${moduleWeekId}`);
}
async function uploadMaterial(formData) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || session.user.role !== 'PUBLIKASI') throw new Error('Unauthorized');
    const file = formData.get('file');
    const moduleWeekId = formData.get('moduleWeekId');
    if (!file || !moduleWeekId) throw new Error('Missing file or moduleWeekId');
    // Convert to Buffer
    const buffer = Buffer.from(await file.arrayBuffer());
    // Create a safe path
    // Use 'materials' bucket. Ensure it exists or change if needed.
    const path = `${moduleWeekId}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
    const { path: storagePath } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uploadFile"])('materials', path, buffer, {
        contentType: file.type,
        upsert: true
    });
    return storagePath;
}
async function uploadTaskFile(file, moduleWeekId) {
    const buffer = Buffer.from(await file.arrayBuffer());
    const path = `${moduleWeekId}/tasks/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
    const { path: storagePath } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uploadFile"])('materials', path, buffer, {
        contentType: file.type,
        upsert: true
    });
    return storagePath;
}
async function createTask(formData) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || session.user.role !== 'PUBLIKASI') throw new Error('Unauthorized');
    const moduleWeekId = formData.get('moduleWeekId');
    const title = formData.get('title');
    const type = formData.get('type');
    const instructions = formData.get('instructions');
    const instructionFile = formData.get('instructionFile');
    const templateFile = formData.get('templateFile');
    let instructionPath = null;
    let templatePath = null;
    if (instructionFile && instructionFile.size > 0) {
        instructionPath = await uploadTaskFile(instructionFile, moduleWeekId);
    }
    if (templateFile && templateFile.size > 0) {
        templatePath = await uploadTaskFile(templateFile, moduleWeekId);
    }
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].task.create({
        data: {
            moduleWeekId,
            title,
            type,
            instructions,
            instructionPath,
            templatePath,
            allowCopyPaste: type.toUpperCase() === 'JURNAL'
        }
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/dashboard/publikasi/modules/${moduleWeekId}`);
}
async function updateTask(formData) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || session.user.role !== 'PUBLIKASI') throw new Error('Unauthorized');
    const taskId = formData.get('taskId');
    if (!taskId) throw new Error('Task ID is required');
    const title = formData.get('title');
    const instructions = formData.get('instructions');
    const type = formData.get('type');
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].task.update({
        where: {
            id: taskId
        },
        data: {
            title,
            instructions,
            ...type ? {
                type
            } : {}
        }
    });
    const task = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].task.findUnique({
        where: {
            id: taskId
        },
        select: {
            moduleWeekId: true
        }
    });
    if (task) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/dashboard/publikasi/modules/${task.moduleWeekId}`);
    }
}
async function deleteTask(taskId) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || session.user.role !== 'PUBLIKASI') throw new Error('Unauthorized');
    const task = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].task.findUnique({
        where: {
            id: taskId
        }
    });
    if (!task) throw new Error('Task not found');
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].task.delete({
        where: {
            id: taskId
        }
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/dashboard/publikasi/modules/${task.moduleWeekId}`);
}
async function deleteContent(contentId) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || session.user.role !== 'PUBLIKASI') throw new Error('Unauthorized');
    const content = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].content.findUnique({
        where: {
            id: contentId
        }
    });
    if (!content) throw new Error('Content not found');
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].content.delete({
        where: {
            id: contentId
        }
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/dashboard/publikasi/modules/${content.moduleWeekId}`);
}
async function createQuestion(taskId, data) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || session.user.role !== 'PUBLIKASI') throw new Error('Unauthorized');
    // Calculate questionNo
    const lastQuestion = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].question.findFirst({
        where: {
            taskId
        },
        orderBy: {
            questionNo: 'desc'
        }
    });
    const questionNo = (lastQuestion?.questionNo || 0) + 1;
    const question = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].question.create({
        data: {
            taskId,
            type: data.type,
            prompt: data.prompt,
            questionNo,
            optionsJson: data.options || null,
            points: data.points
        }
    });
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].answerKey.create({
        data: {
            questionId: question.id,
            correctAnswer: data.correctAnswer
        }
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/dashboard/publikasi/modules`);
}
async function updateQuestion(formData) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || session.user.role !== 'PUBLIKASI') throw new Error('Unauthorized');
    const questionId = formData.get('questionId');
    if (!questionId) throw new Error('Question ID is required');
    const prompt = formData.get('prompt');
    const correctAnswer = formData.get('correctAnswer');
    const points = parseFloat(formData.get('points') || '0');
    const optionsValue = formData.get('options');
    const options = typeof optionsValue === 'string' ? optionsValue : '';
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].question.update({
        where: {
            id: questionId
        },
        data: {
            prompt,
            points,
            optionsJson: options || null
        }
    });
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].answerKey.update({
        where: {
            questionId
        },
        data: {
            correctAnswer
        }
    });
    const question = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].question.findUnique({
        where: {
            id: questionId
        },
        select: {
            task: {
                select: {
                    moduleWeekId: true
                }
            }
        }
    });
    if (question?.task.moduleWeekId) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/dashboard/publikasi/modules/${question.task.moduleWeekId}`);
    }
}
async function startTP(moduleWeekId) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || session.user.role !== 'PUBLIKASI') throw new Error('Unauthorized');
    // Update all TP tasks in this module to be "open"
    // We could add an `isOpen` or `startedAt` field to Task, but for simplicity:
    // Create a SystemSetting or LiveSession-like flag.
    // For hackathon, we'll use Announcement as a signal.
    const module = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].moduleWeek.findUnique({
        where: {
            id: moduleWeekId
        },
        include: {
            course: true
        }
    });
    if (!module) throw new Error('Module not found');
    // Create an announcement to signal TP is open
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].announcement.create({
        data: {
            courseId: module.courseId,
            title: `TP Week ${module.weekNo} is Now OPEN`,
            body: `Tugas Pendahuluan untuk ${module.title} sudah dibuka. Silakan submit sebelum deadline.`,
            createdById: session.user.id,
            isPinned: true
        }
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])('/dashboard/publikasi/modules');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])('/dashboard/praktikan');
    return {
        success: true
    };
}
async function createModuleWeek(data) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || session.user.role !== 'PUBLIKASI') throw new Error('Unauthorized');
    if (!data.courseId || !data.weekNo || !data.title || !data.releaseAt) {
        throw new Error('Missing required fields');
    }
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].moduleWeek.create({
        data: {
            courseId: data.courseId,
            weekNo: data.weekNo,
            title: data.title,
            description: data.description || null,
            releaseAt: data.releaseAt,
            deadlineTP: data.deadlineTP || null,
            hasCodeBased: false,
            hasMCQ: false,
            hasUploadOnly: false
        }
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])('/dashboard/publikasi/modules');
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    createContent,
    uploadMaterial,
    uploadTaskFile,
    createTask,
    updateTask,
    deleteTask,
    deleteContent,
    createQuestion,
    updateQuestion,
    startTP,
    createModuleWeek
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createContent, "600f03de529dce81bfbf666534ae80d2c21ae11803", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(uploadMaterial, "40aa9947d1dba9fe21117b5a3eab47f2d01f8afb57", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(uploadTaskFile, "60d4df440faf09b82389496ce414cabb14e1d7414f", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createTask, "40e906fc0cd018a0a3b6da8de345af3494607cdf30", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(updateTask, "4034ceb19e11d9c2d9b52db62823108ab9e192811a", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(deleteTask, "4029f378fc0ab886944db13c9633da4035b2a94fd5", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(deleteContent, "40ced35877719c41ca82ada3a77ebb30f8fb2b23f3", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createQuestion, "60b8a894f2e3f2ebefd1f591d653d0d30eda11320b", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(updateQuestion, "4005a3c2b8d22ac85a53cd5c2e0dc8f2131c07c9d3", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(startTP, "40e46a0c097fc450db95c0db91dee982239fa26e95", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createModuleWeek, "40ac5be5e44865bada321dfecbc470b89b110f458f", null);
}),
"[project]/.next-internal/server/app/dashboard/publikasi/modules/[moduleWeekId]/page/actions.js { ACTIONS_MODULE0 => \"[project]/app/actions/publikasi.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/actions/publikasi.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
}),
"[project]/.next-internal/server/app/dashboard/publikasi/modules/[moduleWeekId]/page/actions.js { ACTIONS_MODULE0 => \"[project]/app/actions/publikasi.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "4005a3c2b8d22ac85a53cd5c2e0dc8f2131c07c9d3",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["updateQuestion"],
    "4029f378fc0ab886944db13c9633da4035b2a94fd5",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["deleteTask"],
    "4034ceb19e11d9c2d9b52db62823108ab9e192811a",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["updateTask"],
    "40aa9947d1dba9fe21117b5a3eab47f2d01f8afb57",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uploadMaterial"],
    "40ac5be5e44865bada321dfecbc470b89b110f458f",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createModuleWeek"],
    "40ced35877719c41ca82ada3a77ebb30f8fb2b23f3",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["deleteContent"],
    "40e46a0c097fc450db95c0db91dee982239fa26e95",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["startTP"],
    "40e906fc0cd018a0a3b6da8de345af3494607cdf30",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createTask"],
    "600f03de529dce81bfbf666534ae80d2c21ae11803",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createContent"],
    "60b8a894f2e3f2ebefd1f591d653d0d30eda11320b",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createQuestion"],
    "60d4df440faf09b82389496ce414cabb14e1d7414f",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uploadTaskFile"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$dashboard$2f$publikasi$2f$modules$2f5b$moduleWeekId$5d2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/dashboard/publikasi/modules/[moduleWeekId]/page/actions.js { ACTIONS_MODULE0 => "[project]/app/actions/publikasi.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$publikasi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/actions/publikasi.ts [app-rsc] (ecmascript)");
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__3e5a2428._.js.map