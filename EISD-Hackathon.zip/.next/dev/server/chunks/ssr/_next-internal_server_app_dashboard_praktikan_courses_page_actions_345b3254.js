module.exports = [
"[project]/.next-internal/server/app/dashboard/praktikan/courses/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_praktikan_courses_page_actions_345b3254.js.map