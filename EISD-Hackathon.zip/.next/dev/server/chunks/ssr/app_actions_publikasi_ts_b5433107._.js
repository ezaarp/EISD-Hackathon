module.exports = [
"[project]/app/actions/publikasi.ts [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/app_actions_a30ee6ab._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/app/actions/publikasi.ts [app-ssr] (ecmascript)");
    });
});
}),
];