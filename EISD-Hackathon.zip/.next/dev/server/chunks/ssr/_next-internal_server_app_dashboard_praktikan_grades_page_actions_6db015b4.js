module.exports = [
"[project]/.next-internal/server/app/dashboard/praktikan/grades/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_praktikan_grades_page_actions_6db015b4.js.map