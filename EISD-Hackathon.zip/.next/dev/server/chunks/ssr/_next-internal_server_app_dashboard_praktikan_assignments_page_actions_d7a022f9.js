module.exports = [
"[project]/.next-internal/server/app/dashboard/praktikan/assignments/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_praktikan_assignments_page_actions_d7a022f9.js.map