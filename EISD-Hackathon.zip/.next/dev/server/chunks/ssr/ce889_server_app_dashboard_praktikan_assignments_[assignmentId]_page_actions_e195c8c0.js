module.exports = [
"[project]/.next-internal/server/app/dashboard/praktikan/assignments/[assignmentId]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_dashboard_praktikan_assignments_%5BassignmentId%5D_page_actions_e195c8c0.js.map