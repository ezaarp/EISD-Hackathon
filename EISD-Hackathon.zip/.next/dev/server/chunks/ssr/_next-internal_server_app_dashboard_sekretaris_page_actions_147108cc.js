module.exports = [
"[project]/.next-internal/server/app/dashboard/sekretaris/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_sekretaris_page_actions_147108cc.js.map