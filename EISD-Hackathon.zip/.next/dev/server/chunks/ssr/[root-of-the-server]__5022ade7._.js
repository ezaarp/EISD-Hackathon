module.exports = [
"[externals]/@prisma/client [external] (@prisma/client, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client", () => require("@prisma/client"));

module.exports = mod;
}),
"[project]/lib/prisma.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "prisma",
    ()=>prisma
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs)");
;
const globalForPrisma = globalThis;
// Use a dummy URL during build if DATABASE_URL is not set
const databaseUrl = process.env.DATABASE_URL || 'postgresql://dummy:dummy@localhost:5432/dummy';
const prisma = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["PrismaClient"]({
    log: ("TURBOPACK compile-time truthy", 1) ? [
        'error',
        'warn'
    ] : "TURBOPACK unreachable",
    datasources: {
        db: {
            url: databaseUrl
        }
    }
});
if ("TURBOPACK compile-time truthy", 1) {
    globalForPrisma.prisma = prisma;
}
const __TURBOPACK__default__export__ = prisma;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/querystring [external] (querystring, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("querystring", () => require("querystring"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/lib/auth.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authOptions",
    ()=>authOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/providers/credentials.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$auth$2f$prisma$2d$adapter$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@auth/prisma-adapter/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bcryptjs/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs)");
;
;
;
;
;
const authOptions = {
    adapter: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$auth$2f$prisma$2d$adapter$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PrismaAdapter"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"]),
    providers: [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])({
            name: 'Credentials',
            credentials: {
                username: {
                    label: 'Username',
                    type: 'text',
                    placeholder: 'NIM atau Kode Asprak'
                },
                password: {
                    label: 'Password',
                    type: 'password'
                },
                roleGate: {
                    label: 'Role Gate',
                    type: 'text'
                }
            },
            async authorize (credentials) {
                if (!credentials?.username || !credentials?.password) {
                    throw new Error('Username dan password harus diisi');
                }
                // Find user
                const user = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].user.findUnique({
                    where: {
                        username: credentials.username
                    }
                });
                if (!user || !user.isActive) {
                    throw new Error('Username atau password salah');
                }
                // Verify password
                const isPasswordValid = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].compare(credentials.password, user.passwordHash);
                if (!isPasswordValid) {
                    throw new Error('Username atau password salah');
                }
                // Enforce button-role mapping when provided
                if (credentials.roleGate) {
                    const gate = credentials.roleGate;
                    const role = user.role;
                    const allowedRoles = {
                        praktikan: [
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].PRAKTIKAN
                        ],
                        asisten: [
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].ASISTEN,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].MEDIA,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].KOORDINATOR,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].SEKRETARIS,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].PUBLIKASI,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].KOMDIS
                        ],
                        dosen: [
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].DOSEN,
                            __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["UserRole"].LABORAN
                        ]
                    };
                    const allowed = allowedRoles[gate];
                    if (allowed && !allowed.includes(role)) {
                        throw new Error('Silakan login melalui tombol yang sesuai dengan peran Anda');
                    }
                }
                return {
                    id: user.id,
                    username: user.username,
                    name: user.name,
                    email: user.email,
                    role: user.role
                };
            }
        })
    ],
    session: {
        strategy: 'jwt',
        maxAge: 30 * 24 * 60 * 60
    },
    pages: {
        signIn: '/login',
        error: '/login'
    },
    callbacks: {
        async jwt ({ token, user }) {
            if (user) {
                token.id = user.id;
                token.username = user.username;
                token.role = user.role;
            }
            return token;
        },
        async session ({ session, token }) {
            if (session.user) {
                session.user.id = token.id;
                session.user.username = token.username;
                session.user.role = token.role;
            }
            return session;
        }
    },
    secret: process.env.NEXTAUTH_SECRET,
    debug: ("TURBOPACK compile-time value", "development") === 'development'
};
}),
"[project]/lib/supabase.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "deleteFile",
    ()=>deleteFile,
    "getFileUrl",
    ()=>getFileUrl,
    "supabase",
    ()=>supabase,
    "supabaseAdmin",
    ()=>supabaseAdmin,
    "uploadFile",
    ()=>uploadFile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-rsc] (ecmascript) <locals>");
;
const supabaseUrl = ("TURBOPACK compile-time value", "https://oyfigjfooeoabvkavubu.supabase.co");
const supabaseAnonKey = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im95ZmlnamZvb2VvYWJ2a2F2dWJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQzMjU0MDMsImV4cCI6MjA3OTkwMTQwM30.VO4fK5BbLQh0BqhN8K4GW4Cg-wWLhsvlwWpVQpSjBvU");
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseAnonKey);
// Server-side Supabase client with service role (for admin operations)
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabaseAdmin = supabaseServiceKey ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseServiceKey) : null;
async function uploadFile(bucket, path, file, options) {
    const client = supabaseAdmin || supabase;
    const { data, error } = await client.storage.from(bucket).upload(path, file, {
        contentType: options?.contentType,
        cacheControl: options?.cacheControl || '3600',
        upsert: options?.upsert || false
    });
    if (error) {
        throw error;
    }
    // Get public URL
    const { data: urlData } = client.storage.from(bucket).getPublicUrl(path);
    return {
        path: data.path,
        publicUrl: urlData.publicUrl
    };
}
async function deleteFile(bucket, path) {
    const client = supabaseAdmin || supabase;
    const { error } = await client.storage.from(bucket).remove([
        path
    ]);
    if (error) {
        throw error;
    }
    return true;
}
function getFileUrl(bucket, path) {
    // Private buckets (evidence, violations, permissions) need signed URLs
    const privateBuckets = [
        'evidence',
        'violations',
        'permissions'
    ];
    if (privateBuckets.includes(bucket)) {
        // For private buckets, we need to generate signed URLs on the server
        // This function will return a path that will be handled by an API route
        return `/api/files/${bucket}/${encodeURIComponent(path)}`;
    }
    // For public buckets, use public URL
    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    return data.publicUrl;
}
const __TURBOPACK__default__export__ = supabase;
}),
"[project]/app/actions/live-session.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"400afc21ff63019e5484fcdc5fe23c49a11e05bc58":"backStage","402d899acbd8b6634bbb69ef5bf71a9fd9d7bb63a9":"getActiveSessionForStudent","402da899936e361e04fec108307ae00ad5e86b8d54":"endLiveSession","407ee78ed03e4dbf92b589ff3fcec0bb015d49f797":"startLiveSession","40be798f743553d9e586be40fcb906b0b67151280b":"getLiveSession","6024b25e92f0ce6a5caef2f2f830bb8e1ea6fff962":"createLiveSession","70b178d9562561d917e83483c6c955ab561c8df602":"changeStage"},"",""] */ __turbopack_context__.s([
    "backStage",
    ()=>backStage,
    "changeStage",
    ()=>changeStage,
    "createLiveSession",
    ()=>createLiveSession,
    "endLiveSession",
    ()=>endLiveSession,
    "getActiveSessionForStudent",
    ()=>getActiveSessionForStudent,
    "getLiveSession",
    ()=>getLiveSession,
    "startLiveSession",
    ()=>startLiveSession
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/auth.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/cache.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
;
;
// Helper to broadcast event via Supabase Realtime
async function broadcastLiveEvent(liveSessionId, event, payload) {
    if (__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["supabaseAdmin"]) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["supabaseAdmin"].channel(`live-${liveSessionId}`).send({
            type: 'broadcast',
            event: event,
            payload: payload
        });
    }
}
async function getLiveSession(sessionId) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session) throw new Error('Unauthorized');
    return await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveSession.findUnique({
        where: {
            id: sessionId
        },
        include: {
            shift: {
                include: {
                    course: true
                }
            },
            moduleWeek: {
                include: {
                    tasks: {
                        include: {
                            questions: true
                        }
                    }
                }
            },
            stages: {
                orderBy: {
                    stageOrder: 'asc'
                }
            },
            attendances: {
                include: {
                    student: {
                        select: {
                            id: true,
                            name: true,
                            username: true
                        }
                    }
                }
            }
        }
    });
}
async function createLiveSession(shiftId, moduleWeekId) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || ![
        'PUBLIKASI',
        'LABORAN',
        'ADMIN'
    ].includes(session.user.role)) {
        throw new Error('Unauthorized');
    }
    // Check if session already exists
    const existing = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveSession.findFirst({
        where: {
            shiftId,
            moduleWeekId,
            status: {
                not: 'CANCELLED'
            }
        }
    });
    if (existing) {
        // If existing is Completed, allow creating a new one or restart logic?
        // User complained: "end sesi, habis itu logout dan login lagi. tiba tiba, tidak bisa melakukan start sesi lagi maupun end"
        // If status is COMPLETED, we should probably allow creating a NEW session for re-run or just fail.
        // But if status is ACTIVE/PAUSED/DRAFT, we return existing.
        if (existing.status === 'COMPLETED' || existing.status === 'CANCELLED') {
        // Allow creating new session if previous is done
        } else {
            return {
                success: true,
                sessionId: existing.id
            };
        }
    }
    const newSession = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveSession.create({
        data: {
            shiftId,
            moduleWeekId,
            status: 'DRAFT',
            controlledById: session.user.id
        }
    });
    return {
        success: true,
        sessionId: newSession.id
    };
}
async function startLiveSession(sessionId) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || ![
        'PUBLIKASI'
    ].includes(session.user.role)) {
        throw new Error('Unauthorized');
    }
    // Start with OPENING stage
    const liveSession = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveSession.update({
        where: {
            id: sessionId
        },
        data: {
            status: 'ACTIVE',
            startedAt: new Date(),
            currentStageIndex: 0
        }
    });
    // Create first stage record
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveStage.create({
        data: {
            liveSessionId: sessionId,
            type: 'OPENING',
            stageOrder: 0,
            durationSec: 600,
            startedAt: new Date()
        }
    });
    await broadcastLiveEvent(sessionId, 'session_start', {
        status: 'ACTIVE'
    });
    await broadcastLiveEvent(sessionId, 'stage_change', {
        stage: 'OPENING',
        index: 0
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/live/${sessionId}`);
    return {
        success: true
    };
}
async function changeStage(sessionId, stageType, durationSec) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || ![
        'PUBLIKASI'
    ].includes(session.user.role)) {
        throw new Error('Unauthorized');
    }
    const liveSession = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveSession.findUnique({
        where: {
            id: sessionId
        },
        include: {
            stages: true
        }
    });
    if (!liveSession) throw new Error("Session not found");
    // End previous stage
    const currentStage = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveStage.findFirst({
        where: {
            liveSessionId: sessionId,
            endedAt: null
        },
        orderBy: {
            stageOrder: 'desc'
        }
    });
    if (currentStage) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveStage.update({
            where: {
                id: currentStage.id
            },
            data: {
                endedAt: new Date()
            }
        });
        // AUTO-SUBMIT LOGIC
        const gradedTypes = [
            'PRETEST',
            'JURNAL',
            'POSTTEST'
        ];
        if (gradedTypes.includes(currentStage.type)) {
            const sessionData = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveSession.findUnique({
                where: {
                    id: sessionId
                },
                select: {
                    moduleWeekId: true
                }
            });
            if (sessionData) {
                const taskTypeMap = {
                    'PRETEST': 'PRETEST',
                    'JURNAL': 'JURNAL',
                    'POSTTEST': 'POSTTEST'
                };
                const taskType = taskTypeMap[currentStage.type];
                // @ts-ignore
                const task = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].task.findFirst({
                    where: {
                        moduleWeekId: sessionData.moduleWeekId,
                        type: taskType
                    }
                });
                if (task) {
                    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].submission.updateMany({
                        where: {
                            taskId: task.id,
                            status: 'DRAFT'
                        },
                        data: {
                            status: 'AUTOSUBMITTED',
                            submittedAt: new Date()
                        }
                    });
                }
            }
        }
    }
    const nextIndex = liveSession.currentStageIndex + 1;
    // Create new stage
    const newStage = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveStage.create({
        data: {
            liveSessionId: sessionId,
            type: stageType,
            stageOrder: nextIndex,
            durationSec: durationSec,
            startedAt: new Date()
        }
    });
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveSession.update({
        where: {
            id: sessionId
        },
        data: {
            currentStageIndex: nextIndex
        }
    });
    await broadcastLiveEvent(sessionId, 'stage_change', {
        stage: stageType,
        index: nextIndex,
        duration: durationSec,
        startedAt: newStage.startedAt
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/live/${sessionId}`);
    return {
        success: true
    };
}
async function backStage(sessionId) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || session.user.role !== 'PUBLIKASI') {
        throw new Error('Unauthorized');
    }
    const liveSession = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveSession.findUnique({
        where: {
            id: sessionId
        },
        include: {
            stages: {
                orderBy: {
                    stageOrder: 'desc'
                }
            }
        }
    });
    if (!liveSession || liveSession.currentStageIndex <= 0) {
        throw new Error('Cannot go back from first stage');
    }
    // End current stage
    const currentStage = liveSession.stages[0];
    if (currentStage && !currentStage.endedAt) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveStage.update({
            where: {
                id: currentStage.id
            },
            data: {
                endedAt: new Date()
            }
        });
    }
    // Go back one index
    const prevIndex = liveSession.currentStageIndex - 1;
    const prevStage = liveSession.stages.find((s)=>s.stageOrder === prevIndex);
    if (!prevStage) {
        throw new Error('Previous stage not found');
    }
    // Reopen previous stage
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveStage.update({
        where: {
            id: prevStage.id
        },
        data: {
            endedAt: null,
            startedAt: new Date() // Restart timer
        }
    });
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveSession.update({
        where: {
            id: sessionId
        },
        data: {
            currentStageIndex: prevIndex
        }
    });
    await broadcastLiveEvent(sessionId, 'stage_change', {
        stage: prevStage.type,
        index: prevIndex,
        duration: prevStage.durationSec,
        startedAt: new Date()
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/live/${sessionId}`);
    return {
        success: true
    };
}
async function endLiveSession(sessionId) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session || ![
        'PUBLIKASI'
    ].includes(session.user.role)) {
        throw new Error('Unauthorized');
    }
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveSession.update({
        where: {
            id: sessionId
        },
        data: {
            status: 'COMPLETED',
            endedAt: new Date()
        }
    });
    // End any active stage
    const currentStage = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveStage.findFirst({
        where: {
            liveSessionId: sessionId,
            endedAt: null
        },
        orderBy: {
            stageOrder: 'desc'
        }
    });
    if (currentStage) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveStage.update({
            where: {
                id: currentStage.id
            },
            data: {
                endedAt: new Date()
            }
        });
    }
    await broadcastLiveEvent(sessionId, 'session_end', {
        status: 'COMPLETED'
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(`/live/${sessionId}`);
    return {
        success: true
    };
}
async function getActiveSessionForStudent(studentId) {
    // Find active session for the student's assigned shift
    const assignment = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].studentAssignment.findFirst({
        where: {
            studentId
        },
        include: {
            shift: true
        }
    });
    if (!assignment) return null;
    const activeSession = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].liveSession.findFirst({
        where: {
            shiftId: assignment.shiftId,
            status: 'ACTIVE'
        },
        include: {
            moduleWeek: true,
            stages: {
                orderBy: {
                    stageOrder: 'desc'
                },
                take: 1
            }
        }
    });
    return activeSession;
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    getLiveSession,
    createLiveSession,
    startLiveSession,
    changeStage,
    backStage,
    endLiveSession,
    getActiveSessionForStudent
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getLiveSession, "40be798f743553d9e586be40fcb906b0b67151280b", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createLiveSession, "6024b25e92f0ce6a5caef2f2f830bb8e1ea6fff962", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(startLiveSession, "407ee78ed03e4dbf92b589ff3fcec0bb015d49f797", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(changeStage, "70b178d9562561d917e83483c6c955ab561c8df602", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(backStage, "400afc21ff63019e5484fcdc5fe23c49a11e05bc58", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(endLiveSession, "402da899936e361e04fec108307ae00ad5e86b8d54", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getActiveSessionForStudent, "402d899acbd8b6634bbb69ef5bf71a9fd9d7bb63a9", null);
}),
"[project]/app/actions/submission.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"405f1363b4b4e6e6700fcd588b8618dfef8a0af854":"uploadEvidence","7008072e7a5434a3cfec3f68454d1ff8017df8eba4":"submitMCQ","7896dc8c36009457217fe228bec169f5747f0052d9":"submitCode"},"",""] */ __turbopack_context__.s([
    "submitCode",
    ()=>submitCode,
    "submitMCQ",
    ()=>submitMCQ,
    "uploadEvidence",
    ()=>uploadEvidence
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/auth.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/cache.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
;
;
async function submitMCQ(taskId, answers, liveSessionId) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session) throw new Error('Unauthorized');
    const task = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].task.findUnique({
        where: {
            id: taskId
        },
        include: {
            questions: {
                include: {
                    answerKey: true
                }
            }
        }
    });
    if (!task) throw new Error('Task not found');
    // Calculate score
    let totalPoints = 0;
    let earnedPoints = 0;
    const processedAnswers = [];
    const normalize = (value)=>typeof value === 'string' ? value.trim() : '';
    const parseOptions = (optionsJson)=>{
        if (!optionsJson) return [];
        try {
            const parsed = JSON.parse(optionsJson);
            if (Array.isArray(parsed)) {
                return parsed.map((opt)=>typeof opt === 'string' ? opt : String(opt));
            }
        } catch (error) {
            console.warn('Failed to parse options JSON', error);
        }
        return [];
    };
    for (const question of task.questions){
        const studentAnswer = normalize(answers[question.id]);
        const points = question.points || 10; // Default points if not set
        totalPoints += points;
        if (studentAnswer) {
            const rawAnswerKey = normalize(question.answerKey?.correctAnswer);
            let isCorrect = false;
            if (rawAnswerKey) {
                // Primary: compare raw strings (covers numeric indexes stored as strings)
                if (rawAnswerKey === studentAnswer) {
                    isCorrect = true;
                } else {
                    const options = parseOptions(question.optionsJson);
                    const studentIndex = Number(studentAnswer);
                    // If answer key stored as option text, compare selected option text
                    if (!Number.isNaN(studentIndex) && options[studentIndex]) {
                        const selectedOption = normalize(options[studentIndex]);
                        if (selectedOption && selectedOption.toLowerCase() === rawAnswerKey.toLowerCase()) {
                            isCorrect = true;
                        }
                    }
                    // If answer key stored as letter (A, B, C...), map to index
                    if (!isCorrect && /^[A-Za-z]$/.test(rawAnswerKey) && !Number.isNaN(studentIndex)) {
                        const letterIndex = rawAnswerKey.toUpperCase().charCodeAt(0) - 65;
                        if (letterIndex === studentIndex) {
                            isCorrect = true;
                        }
                    }
                }
            }
            if (isCorrect) {
                earnedPoints += points;
            }
            processedAnswers.push({
                questionId: question.id,
                answer: studentAnswer,
                isCorrect
            });
        }
    }
    const finalScore = totalPoints > 0 ? earnedPoints / totalPoints * 100 : 0;
    // Check for existing submission for this TASK (not per question)
    const existingSubmission = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].submission.findFirst({
        where: {
            taskId,
            studentId: session.user.id,
            questionId: null // Task-level submission
        }
    });
    let submissionId = existingSubmission?.id;
    if (existingSubmission) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].submission.update({
            where: {
                id: existingSubmission.id
            },
            data: {
                answersJson: JSON.stringify(processedAnswers),
                status: 'GRADED',
                submittedAt: new Date(),
                liveSessionId
            }
        });
    } else {
        const sub = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].submission.create({
            data: {
                taskId,
                studentId: session.user.id,
                liveSessionId,
                answersJson: JSON.stringify(processedAnswers),
                status: 'GRADED',
                submittedAt: new Date(),
                questionId: null
            }
        });
        submissionId = sub.id;
    }
    // Create or Update Grade immediately
    const existingGrade = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].grade.findUnique({
        where: {
            submissionId: submissionId
        }
    });
    const gradeData = {
        score: finalScore,
        status: 'RECOMMENDED',
        gradedByAI: true,
        notes: 'Auto-graded MCQ',
        breakdownJson: JSON.stringify(processedAnswers)
    };
    if (existingGrade) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].grade.update({
            where: {
                id: existingGrade.id
            },
            data: gradeData
        });
    } else {
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].grade.create({
            data: {
                submission: {
                    connect: {
                        id: submissionId
                    }
                },
                ...gradeData
            }
        });
    }
    return {
        success: true,
        score: finalScore,
        total: 100,
        pointsEarned: earnedPoints,
        maxPoints: totalPoints
    };
}
async function submitCode(taskId, questionId, code, liveSessionId) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session) throw new Error('Unauthorized');
    const question = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].question.findUnique({
        where: {
            id: questionId
        },
        include: {
            answerKey: true
        }
    });
    if (!question) throw new Error('Question not found');
    // Create/Update Submission
    // Check if draft exists?
    const existing = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].submission.findFirst({
        where: {
            taskId,
            questionId,
            studentId: session.user.id
        }
    });
    let submissionId = existing?.id;
    if (existing) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].submission.update({
            where: {
                id: existing.id
            },
            data: {
                contentText: code,
                status: 'SUBMITTED',
                submittedAt: new Date(),
                liveSessionId
            }
        });
    } else {
        const sub = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].submission.create({
            data: {
                taskId,
                questionId,
                studentId: session.user.id,
                liveSessionId,
                contentText: code,
                status: 'SUBMITTED',
                submittedAt: new Date()
            }
        });
        submissionId = sub.id;
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])('/live');
    return {
        success: true
    };
}
async function uploadEvidence(formData) {
    const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["authOptions"]);
    if (!session) throw new Error('Unauthorized');
    const file = formData.get('file');
    const taskId = formData.get('taskId');
    const liveSessionId = formData.get('liveSessionId');
    if (!file || !taskId) throw new Error('Missing required fields');
    // Validate file
    if (file.size === 0) {
        throw new Error('File is empty');
    }
    if (file.size > 10 * 1024 * 1024) {
        throw new Error('File size must be less than 10MB');
    }
    // Convert to Buffer
    const buffer = Buffer.from(await file.arrayBuffer());
    const path = `${session.user.id}/${taskId}/${Date.now()}-${file.name}`;
    // Upload to 'evidence' bucket (private)
    const { path: storagePath } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uploadFile"])('evidence', path, buffer, {
        contentType: file.type,
        upsert: true
    });
    // Try to find existing code submission first
    // Priority 1: Find by liveSessionId and questionId (most specific)
    let codeSubmission = liveSessionId ? await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].submission.findFirst({
        where: {
            taskId,
            studentId: session.user.id,
            liveSessionId,
            questionId: {
                not: null
            }
        },
        orderBy: {
            createdAt: 'desc'
        }
    }) : null;
    // Priority 2: Find any submission with questionId for this task
    if (!codeSubmission) {
        codeSubmission = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].submission.findFirst({
            where: {
                taskId,
                studentId: session.user.id,
                questionId: {
                    not: null
                }
            },
            orderBy: {
                createdAt: 'desc'
            }
        });
    }
    if (codeSubmission) {
        // Attach PDF to existing code submission
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].submission.update({
            where: {
                id: codeSubmission.id
            },
            data: {
                evidencePdfPath: storagePath,
                liveSessionId: liveSessionId || codeSubmission.liveSessionId,
                status: 'SUBMITTED',
                submittedAt: codeSubmission.submittedAt || new Date()
            }
        });
    } else {
        // No code submission found - this shouldn't normally happen for JURNAL tasks
        // Create minimal submission with just the PDF
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["prisma"].submission.create({
            data: {
                taskId,
                studentId: session.user.id,
                liveSessionId,
                evidencePdfPath: storagePath,
                status: 'SUBMITTED',
                submittedAt: new Date()
            }
        });
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])('/dashboard/asisten/grading');
    return {
        success: true
    };
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    submitMCQ,
    submitCode,
    uploadEvidence
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(submitMCQ, "7008072e7a5434a3cfec3f68454d1ff8017df8eba4", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(submitCode, "7896dc8c36009457217fe228bec169f5747f0052d9", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(uploadEvidence, "405f1363b4b4e6e6700fcd588b8618dfef8a0af854", null);
}),
"[project]/.next-internal/server/app/live/[liveSessionId]/page/actions.js { ACTIONS_MODULE0 => \"[project]/app/actions/live-session.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/app/actions/submission.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$live$2d$session$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/actions/live-session.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$submission$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/actions/submission.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
}),
"[project]/.next-internal/server/app/live/[liveSessionId]/page/actions.js { ACTIONS_MODULE0 => \"[project]/app/actions/live-session.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/app/actions/submission.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "400afc21ff63019e5484fcdc5fe23c49a11e05bc58",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$live$2d$session$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["backStage"],
    "402d899acbd8b6634bbb69ef5bf71a9fd9d7bb63a9",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$live$2d$session$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getActiveSessionForStudent"],
    "402da899936e361e04fec108307ae00ad5e86b8d54",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$live$2d$session$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["endLiveSession"],
    "405f1363b4b4e6e6700fcd588b8618dfef8a0af854",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$submission$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["uploadEvidence"],
    "407ee78ed03e4dbf92b589ff3fcec0bb015d49f797",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$live$2d$session$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["startLiveSession"],
    "40be798f743553d9e586be40fcb906b0b67151280b",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$live$2d$session$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getLiveSession"],
    "6024b25e92f0ce6a5caef2f2f830bb8e1ea6fff962",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$live$2d$session$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createLiveSession"],
    "7008072e7a5434a3cfec3f68454d1ff8017df8eba4",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$submission$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["submitMCQ"],
    "70b178d9562561d917e83483c6c955ab561c8df602",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$live$2d$session$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["changeStage"],
    "7896dc8c36009457217fe228bec169f5747f0052d9",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$submission$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["submitCode"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$live$2f5b$liveSessionId$5d2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$app$2f$actions$2f$live$2d$session$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$app$2f$actions$2f$submission$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/live/[liveSessionId]/page/actions.js { ACTIONS_MODULE0 => "[project]/app/actions/live-session.ts [app-rsc] (ecmascript)", ACTIONS_MODULE1 => "[project]/app/actions/submission.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$live$2d$session$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/actions/live-session.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$submission$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/actions/submission.ts [app-rsc] (ecmascript)");
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__5022ade7._.js.map