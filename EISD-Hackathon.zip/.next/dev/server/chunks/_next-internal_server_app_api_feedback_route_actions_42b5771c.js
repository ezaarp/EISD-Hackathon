module.exports = [
"[project]/.next-internal/server/app/api/feedback/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_feedback_route_actions_42b5771c.js.map